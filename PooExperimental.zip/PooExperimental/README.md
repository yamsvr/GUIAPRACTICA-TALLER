# Guía POO — Tutorial Interactivo de Python

Aplicación de consola en Python que guía al estudiante por **18 bloques temáticos** de programación orientada a objetos y fundamentos del lenguaje. Cada bloque contiene ejercicios prácticos ejecutables desde un menú dinámico que descubre los métodos disponibles mediante reflexión.

---

## 1. Estructura del proyecto

```
guia_poo/
├── main.py                        # Punto de entrada
├── README.md
│
├── core/                          # Infraestructura transversal
│   ├── __init__.py
│   ├── utilidades.py              # limpiar, titulo, exito, error, aviso
│   └── validaciones.py            # pedir_texto, pedir_entero, pedir_decimal, pedir_opcion
│
├── menus/                         # Capa de presentación
│   ├── __init__.py
│   ├── menu_general.py            # MenuGeneral (menú raíz)
│   └── menu_bloques.py            # MenuBloques (selección y ejecución de bloques)
│
├── bloques/                       # Módulos de ejercicios (18 bloques)
│   ├── __init__.py
│   ├── bloque0_poo.py
│   ├── bloque1_constructor.py
│   ├── bloque2_tipos_datos.py
│   ├── bloque3_operadores.py
│   ├── bloque4_entrada_salida.py
│   ├── bloque5_condicionales.py
│   ├── bloque6_bucles.py
│   ├── bloque7_funciones.py
│   ├── bloque8_listas.py
│   ├── bloque9_tuplas.py
│   ├── bloque10_diccionarios.py
│   ├── bloque11_conjuntos.py
│   ├── bloque12_excepciones.py
│   ├── bloque13_decoradores.py
│   ├── bloque14_unpacking.py
│   ├── bloque15_orden_superior.py
│   ├── bloque16_archivos_json.py
│   └── bloque17_mixins.py
│
└── datos/                         # Archivos persistidos por los ejercicios
    ├── archivo.txt
    ├── datos.json
    ├── usuarios.json
    └── mixin_reporte.json
```

---

## 2. Arquitectura por capas

```
┌────────────────────────────────────────────────────────┐
│  main.py  →  menus/MenuBloques    (Presentación)       │
└────────────────────────┬───────────────────────────────┘
                         │ reflexión dinámica
                         ▼
┌────────────────────────────────────────────────────────┐
│  bloques/Bloque0…Bloque17         (Ejercicios / Lógica)│
│  Cada clase encapsula los ejercicios de su tema.       │
└────────────────────────┬───────────────────────────────┘
                         │ validación e I/O
                         ▼
┌────────────────────────────────────────────────────────┐
│  core/utilidades.py + validaciones.py  (Infraestructura│
│  limpiar, titulo, exito, error, aviso                  │
│  pedir_texto, pedir_entero, pedir_decimal              │
└────────────────────────┬───────────────────────────────┘
                         │ lee/escribe
                         ▼
              datos/archivo.txt
              datos/datos.json
              datos/usuarios.json
              datos/mixin_reporte.json
```

**Paquete `core/` (infraestructura transversal):**
- `utilidades.py` — funciones de consola: `limpiar`, `titulo`, `exito`, `error`, `aviso`, `pausa`.
- `validaciones.py` — entradas seguras: `pedir_texto`, `pedir_entero`, `pedir_decimal`, `pedir_opcion`.

---

## 3. Flujo general de ejecución

### 3.1 Arranque

[main.py](main.py) importa `MenuBloques` y lanza el menú principal:

```python
from menus.menu_bloques import MenuBloques

app = MenuBloques()
app.mostrar()
```

### 3.2 Menú de bloques

`MenuBloques.mostrar()` lista los 18 bloques disponibles:

```
==============================
     MENÚ DE BLOQUES
==============================
 0. Introducción a la POO
 1. Constructor __init__
 2. Variables y tipos de datos
 3. Operadores
 4. Entrada y salida
 5. Condicionales
 6. Bucles
 7. Funciones
 8. Listas
 9. Tuplas
10. Diccionarios
11. Conjuntos
12. Excepciones
13. Decoradores
14. Unpacking
15. Funciones de orden superior
16. Archivos y JSON
17. Mixins
 0. Salir
```

### 3.3 Selección dinámica de ejercicios

Al elegir un bloque, `MenuBloques` usa **reflexión** para descubrir los métodos de ejercicio disponibles en la clase correspondiente:

1. Importa el módulo del bloque seleccionado.
2. Instancia la clase del bloque.
3. Recorre los métodos con `dir()`, filtrando los que empiezan por `ejercicio_`.
4. Extrae la descripción del **docstring** de cada método con `regex`.
5. Muestra el submenú y ejecuta el ejercicio elegido con `getattr()`.

```
==============================
  BLOQUE 17 — MIXINS
==============================
1. PromedioMixin + Estudiante (promedio de notas)
2. ValidacionMixin + Usuario (validar email y edad)
3. ExportarMixin + Reporte (exportar a JSON y CSV)
0. Volver
```

---

## 4. Bloques de ejercicios

| Bloque | Tema                     | Ejercicios destacados                                             |
|:------:|--------------------------|-------------------------------------------------------------------|
|   0    | Introducción a la POO    | Identificar clases, crear `Persona`, clase vs objeto              |
|   1    | Constructor `__init__`   | `Producto` con validación de precio, `Estudiante` + `@classmethod`|
|   2    | Tipos de datos           | 8 tipos básicos, indexado y slicing de listas                     |
|   3    | Operadores               | Aritméticos, `==` vs `is`, precedencia de operadores             |
|   4    | Entrada y salida         | `input()`, concatenación vs suma numérica                         |
|   5    | Condicionales            | Par/impar, calificaciones A-D, login simple                       |
|   6    | Bucles                   | `while`, `enumerate()`, comprensión de listas                     |
|   7    | Funciones                | `*args`, recursividad (factorial)                                 |
|   8    | Listas                   | `append`, `sort`, `sum/max/min`, referencia vs copia              |
|   9    | Tuplas                   | Inmutabilidad, unpacking con `*`, iterar coordenadas              |
|  10    | Diccionarios             | `[]` vs `.get()`, `.items()`, referencia vs `.copy()`             |
|  11    | Conjuntos                | Unión `\|`, intersección `&`, diferencia `-`, simétrica           |
|  12    | Excepciones              | `ValueError`, `IndexError`, `ZeroDivisionError`                  |
|  13    | Decoradores              | `@iniciar`, `@validar_positivo`, `@log`                           |
|  14    | Unpacking                | `*` en asignación, `*lista` en argumentos, `**dict` para mezclar  |
|  15    | Funciones de orden sup.  | `map()`, `filter()`, `reduce()` con lambdas                       |
|  16    | Archivos y JSON          | Leer/escribir `.txt`, guardar y cargar `.json`                    |
|  17    | Mixins                   | `PromedioMixin`, `ValidacionMixin`, `ExportarMixin`               |

---

## 5. Modelo de datos (JSON)

### `datos/datos.json`
```json
{ "x": 30, "y": 10 }
```

### `datos/usuarios.json`
```json
[
  { "nombre": "kevin", "edad": 22 },
  { "nombre": "yamileth", "edad": 40 }
]
```

### `datos/mixin_reporte.json`
```json
[
  { "producto": "cola", "precio": 1 }
]
```

---

## 6. Conceptos POO aplicados

| Concepto                  | Dónde                                                                      |
|---------------------------|----------------------------------------------------------------------------|
| **Encapsulamiento**       | Cada `BloqueN` agrupa sus ejercicios sin exponer detalles internos.        |
| **Herencia**              | `Estudiante` hereda `PromedioMixin`; `Usuario` hereda `ValidacionMixin`.   |
| **Mixins**                | `PromedioMixin`, `ValidacionMixin`, `ExportarMixin` (Bloque 17).           |
| **Clases abstractas**     | Estructura uniforme por convención: métodos `ejercicio_N()` en cada bloque.|
| **Reflexión**             | `MenuBloques` usa `dir()` + `getattr()` para descubrir ejercicios dinámicamente. |
| **Decoradores**           | `@iniciar`, `@validar_positivo`, `@log` en Bloque 13.                     |
| **Métodos de clase**      | `Estudiante.from_diccionario()` con `@classmethod` en Bloque 1.           |
| **Serialización**         | Bloques 16 y 17 usan `json.dump` / `json.load` para persistencia.         |
| **Separación de capas**   | Presentación (`menus/`) ↔ Lógica (`bloques/`) ↔ Utilidades (`core/`).    |

---

## 7. Ejecución

Desde la carpeta raíz del proyecto (`guia_poo/`):

```bash
python main.py
```

No requiere dependencias externas: utiliza únicamente módulos de la librería estándar (`json`, `os`, `abc`, `csv`, `functools`, `re`).

---

## 8. Flujo resumido de un ejercicio

```
Usuario → MenuBloques.mostrar()
               │
               ▼
       Elige bloque (ej. 17)
               │
               ▼
       MenuBloques descubre métodos ejercicio_N()
       via reflexión (dir + regex sobre docstring)
               │
               ▼
       Muestra submenú → Usuario elige ejercicio
               │
               ├─────────────────────────────────────┐
               ▼                                     ▼
     pedir_texto / pedir_entero            Bloque17Mixins.ejercicio_N()
     (core/validaciones.py)                      │
                                                 ▼
                                     Instancia clase con Mixin
                                     Ejecuta lógica del ejercicio
                                                 │
                                                 ▼
                                     datos/mixin_reporte.json  (si persiste)
```



## PROMPTS
```
================================================================
        DOCUMENTACIÓN DE USO DE INTELIGENCIA ARTIFICIAL
                   PROYECTO POOEXPERIMENTAL
================================================================

NOTA: Este documento cubre los 18 bloques del proyecto.
Por cada ejercicio se documenta el uso de IA según lo solicitado.

================================================================
BLOQUE 0 — INTRODUCCIÓN A LA POO
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 0.1: Identificar 5 clases para un sistema de biblioteca
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es una clase en programación orientada a objetos
   y cómo puedo identificar clases dentro de un sistema real.
   Necesito identificar 5 clases para un sistema de biblioteca en Python.
   ¿Qué criterio uso para saber qué debe ser una clase?"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio parecido: propón otro sistema (diferente a
   biblioteca) y pídeme que identifique 5 clases que lo representarían."

4. Resolución del proceso similar (resuelta por mí):
   Sistema: Hospital
   Clases identificadas:
   - Paciente     → persona que recibe atención médica
   - Medico       → profesional que atiende pacientes
   - Cita         → agendamiento entre paciente y médico
   - Habitacion   → espacio físico del hospital
   - Receta       → prescripción médica emitida en una cita

5. ¿Necesitó repetición? No, el concepto quedó claro al analizar
   que los sustantivos del sistema son candidatos a clases.

──────────────────────────────────────────────────────────────
EJERCICIO 0.2: Crear clase Persona e instanciar 3 objetos
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo se crea una clase en Python usando __init__
   y cómo se instancian objetos a partir de ella. El ejercicio
   pide crear una clase Persona con atributos nombre y edad,
   y luego crear 3 objetos distintos."

3. Prompt para generar un proceso similar:
   "Crea un ejercicio similar al de la clase Persona pero usando
   una entidad diferente, por ejemplo un Animal o un Vehículo,
   para que yo lo resuelva solo."

4. Resolución del proceso similar (resuelta por mí):
   class Animal:
       def __init__(self, nombre, especie):
           self.nombre = nombre
           self.especie = especie

   animal1 = Animal("Rex", "Perro")
   animal2 = Animal("Michi", "Gato")
   animal3 = Animal("Paco", "Loro")

   print(f"- {animal1.nombre} es un {animal1.especie}")
   print(f"- {animal2.nombre} es un {animal2.especie}")
   print(f"- {animal3.nombre} es un {animal3.especie}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 0.3: Diferencia entre clase y objeto
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame con un ejemplo simple cuál es la diferencia entre
   una clase y un objeto en Python. ¿Cómo lo explicaría con una
   analogía del mundo real?"

3. Prompt para generar un proceso similar:
   "Dame otro ejemplo con una clase diferente (como Automovil o
   Casa) para que yo explique por mi cuenta la diferencia entre
   clase y objeto usando ese ejemplo."

4. Resolución del proceso similar (resuelta por mí):
   Clase: Automovil → Es el molde/plano que define cómo es un auto.
   Objeto: auto1 = Automovil("Toyota", 2020) → Es un auto real y concreto.

   La clase define QUÉ atributos tendrá (marca, año).
   El objeto ES una instancia específica con valores propios.
   Puedo crear muchos objetos del mismo molde (auto1, auto2, auto3).

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 1 — CONSTRUCTOR __INIT__
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 1.1: Clase Producto con validación de precio negativo
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona el constructor __init__ en Python y
   cómo puedo agregar validaciones dentro de él. El ejercicio
   crea una clase Producto con código, nombre y precio, y lanza
   un ValueError si el precio es negativo."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar al de Producto pero con otra clase
   (como Empleado con salario, o Cuenta bancaria con saldo)
   donde también tenga que validar un valor en el constructor."

4. Resolución del proceso similar (resuelta por mí):
   class CuentaBancaria:
       def __init__(self, titular, saldo):
           self.titular = titular
           self.saldo = saldo
           if self.saldo < 0:
               raise ValueError("El saldo inicial no puede ser negativo")

   cuenta1 = CuentaBancaria("Ana", 500)
   print(f"Titular: {cuenta1.titular}, Saldo: ${cuenta1.saldo}")

   # Prueba de validación:
   try:
       cuenta2 = CuentaBancaria("Luis", -100)
   except ValueError as e:
       print(f"Error: {e}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 1.2: Clase Estudiante con notas=None y @classmethod
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame por qué en Python se usa notas=None como parámetro
   por defecto en lugar de notas=[] en el constructor. También
   explícame qué es @classmethod y cómo se usa con from_diccionario
   para crear objetos desde un diccionario."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar: crea una clase diferente (como
   Producto o Empleado) que también use un parámetro mutable como
   None por defecto, y que tenga un @classmethod para crear el
   objeto desde un diccionario."

4. Resolución del proceso similar (resuelta por mí):
   class Empleado:
       def __init__(self, nombre, habilidades=None):
           self.nombre = nombre
           if habilidades is None:
               self.habilidades = []
           else:
               self.habilidades = habilidades

       @classmethod
       def desde_diccionario(cls, datos):
           return cls(datos['nombre'], datos.get('habilidades', []))

   emp1 = Empleado("Carlos")
   emp2 = Empleado("Mia", ["Python", "SQL"])
   datos = {'nombre': 'Laura', 'habilidades': ['Java', 'HTML']}
   emp3 = Empleado.desde_diccionario(datos)
   print(f"{emp1.nombre}: {emp1.habilidades}")
   print(f"{emp2.nombre}: {emp2.habilidades}")
   print(f"{emp3.nombre}: {emp3.habilidades}")

5. ¿Necesitó repetición? Sí, se necesitó aclarar por qué
   no se usa [] directamente (los mutables por defecto son
   compartidos entre todas las instancias).


================================================================
BLOQUE 2 — VARIABLES Y TIPOS DE DATOS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 2.1: Los 8 tipos de datos básicos en Python
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame los 8 tipos de datos principales en Python:
   str, int, float, bool, list, tuple, dict y set.
   ¿Cómo los identifico con type()? Dame un ejemplo de cada uno."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crea variables con los 8 tipos de datos
   pero con valores distintos a los del ejemplo, y pídeme que use
   type() para mostrar el tipo de cada una."

4. Resolución del proceso similar (resuelta por mí):
   ciudad = "Guayaquil"         # str
   habitantes = 3000000         # int
   temperatura = 28.5           # float
   es_costera = True            # bool
   playas = ["Salinas", "Manta"] # list
   coordenadas = (-2.19, -79.88) # tuple
   datos = {"pais": "Ecuador"}   # dict
   provincias = {"Guayas", "Pichincha"} # set

   print(f"ciudad: {type(ciudad).__name__}")
   print(f"habitantes: {type(habitantes).__name__}")
   print(f"temperatura: {type(temperatura).__name__}")
   print(f"es_costera: {type(es_costera).__name__}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 2.2: Indexing y slicing en listas
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona el indexing (acceso por posición) y
   el slicing (obtener una porción) en listas de Python.
   ¿Qué significa lista[0], lista[-1] y lista[1:4]?"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar: crea una lista con 6 elementos
   distintos y pídeme que acceda al primer elemento, al último,
   y que haga un slice de los elementos del índice 2 al 5."

4. Resolución del proceso similar (resuelta por mí):
   colores = ["rojo", "azul", "verde", "amarillo", "morado", "naranja"]
   print(f"Lista completa:       {colores}")
   print(f"Primer elemento [0]:  {colores[0]}")
   print(f"Último elemento [-1]: {colores[-1]}")
   print(f"Slice [2:5]:          {colores[2:5]}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 2.3: Acceder a elementos de str, list y dict
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo accedo a elementos de un string, una lista y
   un diccionario en Python. ¿Cómo es diferente cada acceso?"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio parecido usando otros valores en un str,
   list y dict para que yo acceda a sus elementos por mi cuenta."

4. Resolución del proceso similar (resuelta por mí):
   pais = "Ecuador"
   notas = [10, 8, 9]
   alumno = {"nombre": "Sofia", "edad": 19}

   print(f"Primera letra del str:   {pais[0]}")
   print(f"Último elemento de lista: {notas[-1]}")
   print(f"Nombre del dict:          {alumno['nombre']}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 3 — OPERADORES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 3.1: Operadores aritméticos
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame los operadores aritméticos de Python: +, -, *, /,
   %, //, **. ¿Cuál es la diferencia entre / y //? ¿Qué hace
   el operador % (módulo)?"

3. Prompt para generar un proceso similar:
   "Dame otros dos números (diferentes a 20 y 4) y pídeme que
   aplique todos los operadores aritméticos sobre ellos."

4. Resolución del proceso similar (resuelta por mí):
   a, b = 15, 6
   print(f"{a} + {b}  = {a + b}")
   print(f"{a} - {b}  = {a - b}")
   print(f"{a} * {b}  = {a * b}")
   print(f"{a} / {b}  = {a / b}")
   print(f"{a} % {b}  = {a % b}")
   print(f"{a} // {b} = {a // b}")
   print(f"{a} ** {b} = {a ** b}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 3.2: Igualdad (==) e identidad (is)
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cuál es la diferencia entre == e is en Python.
   ¿Por qué dos listas con los mismos valores pueden ser == True
   pero is False?"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar usando diccionarios en lugar de
   listas, para que yo verifique si == e is se comportan igual
   con dicts."

4. Resolución del proceso similar (resuelta por mí):
   dict_a = {"x": 1, "y": 2}
   dict_b = {"x": 1, "y": 2}

   print(f"dict_a == dict_b: {dict_a == dict_b}")  # True (mismo contenido)
   print(f"dict_a is dict_b: {dict_a is dict_b}")  # False (objetos distintos)

   # Para que is sea True necesitan ser el mismo objeto:
   dict_c = dict_a
   print(f"dict_a is dict_c: {dict_a is dict_c}")  # True

5. ¿Necesitó repetición? Sí. Se aclaró que is compara identidad
   de objeto (dirección en memoria), no el contenido.

──────────────────────────────────────────────────────────────
EJERCICIO 3.3: Precedencia de operadores
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame el orden de precedencia de operadores en Python.
   ¿Cómo resuelvo paso a paso la expresión 2 + 1 * 2 % 2 + (2**1)//2?"

3. Prompt para generar un proceso similar:
   "Dame otra expresión diferente con al menos 4 operadores
   distintos para que yo resuelva el resultado paso a paso."

4. Resolución del proceso similar (resuelta por mí):
   # Expresión: 3 + 2 ** 2 * 4 // 3 - 1
   # Paso 1: ** → 2**2 = 4
   # Paso 2: * → 4 * 4 = 16
   # Paso 3: // → 16 // 3 = 5
   # Paso 4: + y - → 3 + 5 - 1 = 7
   resultado = 3 + 2 ** 2 * 4 // 3 - 1
   print(f"Resultado: {resultado}")  # 7

5. ¿Necesitó repetición? Sí. Se repitió para comprender que
   ** tiene mayor precedencia que *, / y //.


================================================================
BLOQUE 4 — ENTRADA Y SALIDA
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 4.1: Pedir nombre y edad, mostrar saludo
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar input() en Python para pedir datos al
   usuario. El ejercicio pide el nombre y la edad, y muestra
   un mensaje de saludo con f-string."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar: pedir al usuario su nombre y
   ciudad de origen, y mostrar un mensaje personalizado con esos datos."

4. Resolución del proceso similar (resuelta por mí):
   nombre = input("Ingresa tu nombre: ")
   ciudad = input("Ingresa tu ciudad: ")
   print(f"Hola {nombre}, eres de {ciudad}. ¡Bienvenido!")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 4.2: Pedir dos números, calcular suma y promedio
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo pido dos números al usuario con input(),
   los convierto a float y calculo la suma y el promedio."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: pedir 3 números al usuario y calcular
   su suma, promedio y el mayor de los tres."

4. Resolución del proceso similar (resuelta por mí):
   num1 = float(input("Número 1: "))
   num2 = float(input("Número 2: "))
   num3 = float(input("Número 3: "))

   suma = num1 + num2 + num3
   promedio = suma / 3
   mayor = max(num1, num2, num3)

   print(f"Suma: {suma}")
   print(f"Promedio: {promedio}")
   print(f"Mayor: {mayor}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 4.3: Concatenación vs suma numérica con input()
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame por qué si pido un número con input() y le sumo '5'
   el resultado es una concatenación y no una suma matemática.
   ¿Cuándo Python concatena en vez de sumar?"

3. Prompt para generar un proceso similar:
   "Dame otro ejemplo similar donde quede claro cuándo Python
   concatena y cuándo suma, usando distintos tipos de datos."

4. Resolución del proceso similar (resuelta por mí):
   valor = input("Escribe un número: ")      # Recibe como texto
   print(f"Texto + '10' = {valor + '10'}")   # Concatena: "310" si escribiste 3
   print(f"Número + 10  = {int(valor) + 10}") # Suma: 13 si escribiste 3

   # Conclusión: input() siempre retorna str, hay que convertir con int() o float()

5. ¿Necesitó repetición? Sí. Se aclaró que input() SIEMPRE
   retorna string, sin importar lo que el usuario escriba.


================================================================
BLOQUE 5 — CONDICIONALES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 5.1: Verificar si un número es par o impar
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar if/else en Python para verificar si un
   número es par o impar usando el operador módulo (%)."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio parecido usando if/else: verificar si un
   número ingresado por el usuario es positivo, negativo o cero."

4. Resolución del proceso similar (resuelta por mí):
   numero = int(input("Ingresa un número: "))

   if numero > 0:
       print(f"{numero} es positivo.")
   elif numero < 0:
       print(f"{numero} es negativo.")
   else:
       print("El número es cero.")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 5.2: Calificación en letra según la nota
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar if/elif/else para asignar una letra de
   calificación según una nota numérica. El ejercicio asigna A
   para >=9, B para >=8, C para >=7, D para el resto."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: en vez de A-D, clasificar la edad
   de una persona en categorías (niño, adolescente, adulto, adulto mayor)
   usando if/elif/else."

4. Resolución del proceso similar (resuelta por mí):
   edad = int(input("Ingresa tu edad: "))

   if edad < 12:
       categoria = "Niño"
   elif edad < 18:
       categoria = "Adolescente"
   elif edad < 60:
       categoria = "Adulto"
   else:
       categoria = "Adulto mayor"

   print(f"Edad {edad} → Categoría: {categoria}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 5.3: Sistema de login con usuario y contraseña
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar el operador and en una condición if para
   verificar que dos valores sean correctos a la vez, como en
   un login de usuario y contraseña."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar de acceso, pero que verifique
   también un código PIN además de usuario y contraseña (tres
   condiciones con and)."

4. Resolución del proceso similar (resuelta por mí):
   usuario = input("Usuario: ")
   contrasena = input("Contraseña: ")
   pin = input("PIN: ")

   if usuario == "admin" and contrasena == "abc123" and pin == "0000":
       print("Acceso concedido. ¡Bienvenido!")
   else:
       print("Datos incorrectos. Acceso denegado.")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 6 — BUCLES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 6.1: Imprimir números del 1 al 10 con while
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona el bucle while en Python. ¿Cuándo
   se usa while en vez de for? Muéstrame cómo imprimir los
   números del 1 al 10 con while."

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar con while: imprimir los múltiplos
   de 3 que sean menores a 30."

4. Resolución del proceso similar (resuelta por mí):
   numero = 3
   while numero < 30:
       print(f"  {numero}")
       numero += 3

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 6.2: Recorrer lista con enumerate()
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué hace enumerate() en Python y por qué es útil
   al iterar listas. ¿Qué ventaja tiene sobre usar range(len(lista))?"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar: recorrer una lista de países usando
   enumerate() para mostrar el número de posición y el nombre."

4. Resolución del proceso similar (resuelta por mí):
   paises = ["Ecuador", "Colombia", "Perú", "Chile", "Bolivia"]
   for indice, pais in enumerate(paises):
       print(f"  [{indice}] {pais}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 6.3: List comprehension con cuadrados de pares
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es una list comprehension en Python y cómo
   reemplaza un for + if + append. El ejercicio crea una lista
   de los cuadrados de los números pares del 1 al 10."

3. Prompt para generar un proceso similar:
   "Dame ejercicio parecido con list comprehension: crear una
   lista con los cubos de los números impares del 1 al 15."

4. Resolución del proceso similar (resuelta por mí):
   cubos_impares = [n ** 3 for n in range(1, 16) if n % 2 != 0]
   print(f"Cubos de impares del 1 al 15: {cubos_impares}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 7 — FUNCIONES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 7.1: Función que calcula el doble de un número
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo definir una función en Python con def, cómo
   recibe parámetros y cómo retorna un valor con return."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear una función que calcule el
   triple de un número y otra que calcule su cuadrado."

4. Resolución del proceso similar (resuelta por mí):
   def calcular_triple(numero):
       return numero * 3

   def calcular_cuadrado(numero):
       return numero ** 2

   num = int(input("Ingresa un número: "))
   print(f"Triple de {num}: {calcular_triple(num)}")
   print(f"Cuadrado de {num}: {calcular_cuadrado(num)}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 7.2: Función suma con *args
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué son *args en Python y cómo permiten que una
   función reciba un número variable de argumentos. El ejercicio
   suma todos los números que se le pasen."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear una función con *args que
   calcule el promedio de todos los números que reciba."

4. Resolución del proceso similar (resuelta por mí):
   def calcular_promedio(*numeros):
       if len(numeros) == 0:
           return 0
       return sum(numeros) / len(numeros)

   print(f"Promedio de 5, 10, 15: {calcular_promedio(5, 10, 15)}")
   print(f"Promedio de 3, 7: {calcular_promedio(3, 7)}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 7.3: Función recursiva para factorial
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es la recursividad en Python y cómo funciona
   el caso base. El ejercicio calcula el factorial de n usando
   recursión: n! = n * (n-1)!"

3. Prompt para generar un proceso similar:
   "Dame un ejercicio similar con recursión: calcular la suma
   de los primeros n números naturales (sin usar fórmulas directas)."

4. Resolución del proceso similar (resuelta por mí):
   def suma_naturales(n):
       if n == 0:
           return 0
       return n + suma_naturales(n - 1)

   numero = int(input("Ingresa un número positivo: "))
   print(f"Suma del 1 al {numero} = {suma_naturales(numero)}")

5. ¿Necesitó repetición? Sí. Se repitió para comprender bien
   el caso base (condición de parada) y cómo la función se
   llama a sí misma con un valor menor cada vez.


================================================================
BLOQUE 8 — LISTAS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 8.1: append() y sort() en listas
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar append() para agregar elementos a una
   lista y sort() para ordenarla en Python."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear una lista vacía, agregar
   5 nombres de ciudades con append() y ordenarla alfabéticamente."

4. Resolución del proceso similar (resuelta por mí):
   ciudades = []
   ciudades.append("Quito")
   ciudades.append("Manta")
   ciudades.append("Cuenca")
   ciudades.append("Ambato")
   ciudades.append("Loja")

   print(f"Sin ordenar:  {ciudades}")
   ciudades.sort()
   print(f"Ordenada:     {ciudades}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 8.2: sum(), max() y min() en listas
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame las funciones sum(), max() y min() en Python
   y cómo se aplican a una lista de números."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: pedir al usuario 5 temperaturas y
   calcular la suma, la más alta y la más baja de la semana."

4. Resolución del proceso similar (resuelta por mí):
   temperaturas = []
   for i in range(1, 6):
       t = float(input(f"Temperatura día {i}: "))
       temperaturas.append(t)

   print(f"Temperaturas: {temperaturas}")
   print(f"Suma total:   {sum(temperaturas)}")
   print(f"Más alta:     {max(temperaturas)}")
   print(f"Más baja:     {min(temperaturas)}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 8.3: Referencia vs copia en listas
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame por qué cuando hago copia = lista_original y
   modifico copia, también cambia lista_original. ¿Cómo evito
   esto con .copy()?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio parecido usando una lista de números para
   que yo demuestre la diferencia entre referencia y copia real."

4. Resolución del proceso similar (resuelta por mí):
   numeros = [1, 2, 3, 4, 5]

   # Por referencia (ambas cambian)
   ref = numeros
   ref.append(99)
   print(f"numeros (referencia): {numeros}")  # También tiene 99

   # Por copia real (solo copia cambia)
   numeros2 = [1, 2, 3, 4, 5]
   copia = numeros2.copy()
   copia.append(99)
   print(f"numeros2 (original): {numeros2}")  # Sin cambios
   print(f"copia:               {copia}")

5. ¿Necesitó repetición? Sí. Se aclaró que en Python las listas
   son objetos y las variables guardan referencias, no copias.


================================================================
BLOQUE 9 — TUPLAS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 9.1: Inmutabilidad de las tuplas
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué significa que las tuplas sean inmutables en
   Python y qué error se produce al intentar modificarlas."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear una tupla de días de la semana
   e intentar modificar uno de ellos para ver el TypeError."

4. Resolución del proceso similar (resuelta por mí):
   dias = ("Lunes", "Martes", "Miércoles", "Jueves", "Viernes")
   print(f"Tupla: {dias}")

   try:
       dias[0] = "Domingo"
   except TypeError as e:
       print(f"TypeError: {e}")
       print("→ Las tuplas no se pueden modificar después de creadas.")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 9.2: Unpacking con *resto
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona el unpacking de tuplas en Python
   y para qué sirve el * al desempaquetar (ejemplo: a, b, *resto = tupla)."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar con una tupla de 5 elementos: que
   desempaquete el primero, el último, y el resto en el medio."

4. Resolución del proceso similar (resuelta por mí):
   notas = (8, 9, 7, 10, 6)
   primera, *intermedias, ultima = notas

   print(f"Tupla:        {notas}")
   print(f"Primera:      {primera}")
   print(f"Intermedias:  {intermedias}")
   print(f"Última:       {ultima}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 9.3: Recorrer lista de coordenadas desempaquetando
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo desempaquetar tuplas dentro de un for.
   El ejercicio recorre una lista de coordenadas (x, y) y
   desempaqueta cada par en el propio for."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: recorrer una lista de tuplas
   (nombre, nota) desempaquetando cada una en el for y
   mostrar si el estudiante aprobó (nota >= 7)."

4. Resolución del proceso similar (resuelta por mí):
   estudiantes = [("Ana", 9), ("Luis", 5), ("Mia", 8), ("Pedro", 6)]

   for nombre, nota in estudiantes:
       estado = "Aprobado" if nota >= 7 else "Reprobado"
       print(f"  {nombre}: {nota} → {estado}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 10 — DICCIONARIOS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 10.1: Acceso con [] vs .get()
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame la diferencia entre acceder a un dict con dict['clave']
   y con dict.get('clave'). ¿Cuál es más seguro y por qué?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un diccionario de un producto
   con nombre, precio y categoría, y acceder con [] para claves
   existentes y con .get() para una clave que no existe."

4. Resolución del proceso similar (resuelta por mí):
   producto = {"nombre": "Laptop", "precio": 900, "categoria": "Tecnologia"}

   print(f"Nombre ([]): {producto['nombre']}")
   print(f"Precio ([]): {producto['precio']}")
   print(f"Stock (get): {producto.get('stock', 'No disponible')}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 10.2: Iterar diccionario con .items()
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo recorrer un diccionario en Python con .items()
   y cómo desempaquetar clave y valor en el for."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un dict con 4 países y sus
   capitales, y recorrerlo mostrando 'País: X, Capital: Y'."

4. Resolución del proceso similar (resuelta por mí):
   capitales = {
       "Ecuador": "Quito",
       "Colombia": "Bogotá",
       "Perú": "Lima",
       "Chile": "Santiago"
   }

   for pais, capital in capitales.items():
       print(f"  País: {pais}, Capital: {capital}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 10.3: Referencia vs .copy() en diccionarios
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame por qué al copiar un diccionario con copia=datos
   y modificar copia, también cambia datos. ¿Cómo uso .copy()
   para evitarlo?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio parecido con un diccionario de configuración
   donde muestre la diferencia entre referencia y copia real."

4. Resolución del proceso similar (resuelta por mí):
   config = {"tema": "oscuro", "idioma": "es"}

   # Referencia (ambas cambian)
   alias = config
   alias["fuente"] = "grande"
   print(f"config (ref):  {config}")   # También tiene fuente

   # Copia real
   config2 = {"tema": "oscuro", "idioma": "es"}
   copia = config2.copy()
   copia["fuente"] = "grande"
   print(f"config2:       {config2}")  # Sin cambios
   print(f"copia:         {copia}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 11 — CONJUNTOS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 11.1: Unión, intersección y diferencia de conjuntos
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame las operaciones de conjuntos en Python: unión (|),
   intersección (&) y diferencia (-). ¿Cuándo se usa cada una?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear dos conjuntos de materias que
   llevan dos estudiantes distintos y calcular qué materias
   comparten, cuáles son exclusivas de cada uno."

4. Resolución del proceso similar (resuelta por mí):
   materias_ana = {"Matematicas", "Fisica", "Quimica", "Ingles"}
   materias_luis = {"Fisica", "Historia", "Ingles", "Arte"}

   print(f"Ana:          {materias_ana}")
   print(f"Luis:         {materias_luis}")
   print(f"Comparten:    {materias_ana & materias_luis}")
   print(f"Solo Ana:     {materias_ana - materias_luis}")
   print(f"Solo Luis:    {materias_luis - materias_ana}")
   print(f"Todas:        {materias_ana | materias_luis}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 11.2: Eliminar duplicados con set()
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo los conjuntos (set) en Python no permiten
   elementos duplicados y cómo puedo usarlo para limpiar
   una lista con repeticiones."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: tengo una lista de nombres con
   repetidos, eliminar los duplicados y mostrar cuántos
   nombres únicos hay."

4. Resolución del proceso similar (resuelta por mí):
   nombres = ["Ana", "Luis", "Ana", "Mia", "Luis", "Carlos", "Mia", "Mia"]
   unicos = list(set(nombres))

   print(f"Lista original:    {nombres}")
   print(f"Sin duplicados:    {unicos}")
   print(f"Nombres únicos:    {len(unicos)}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 11.3: Diferencia simétrica (A|B) - (A&B)
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es la diferencia simétrica entre dos conjuntos.
   ¿Por qué (A|B) - (A&B) da los elementos que NO se comparten?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: dados dos conjuntos de números,
   calcular la diferencia simétrica y explicar qué representa."

4. Resolución del proceso similar (resuelta por mí):
   A = {2, 4, 6, 8, 10}
   B = {6, 8, 10, 12, 14}

   diferencia_simetrica = (A | B) - (A & B)

   print(f"A = {A}")
   print(f"B = {B}")
   print(f"Elementos exclusivos (no compartidos): {diferencia_simetrica}")
   # Resultado: {2, 4, 12, 14} — están en A o B pero no en ambos

5. ¿Necesitó repetición? Sí. Se aclaró visualmente con diagramas
   de Venn para entender qué son los elementos "exclusivos".


================================================================
BLOQUE 12 — EXCEPCIONES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 12.1: Capturar ValueError al convertir a int
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona try/except en Python para capturar
   errores. ¿Qué es un ValueError y cuándo ocurre al convertir
   con int()?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: pedir al usuario un número decimal
   y capturar el ValueError si escribe texto en lugar de número."

4. Resolución del proceso similar (resuelta por mí):
   entrada = input("Ingresa un número decimal: ")
   try:
       numero = float(entrada)
       print(f"Conversión exitosa: {numero}")
   except ValueError:
       print(f"ValueError: '{entrada}' no es un número decimal válido")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 12.2: Capturar IndexError al acceder lista[5]
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es un IndexError en Python y cuándo ocurre.
   El ejercicio crea una lista de 3 elementos e intenta acceder
   al índice 5."

3. Prompt para generar un proceso similar:
   "Dame ejercicio parecido: crear una lista de 4 frutas e
   intentar acceder al índice 10 capturando el IndexError."

4. Resolución del proceso similar (resuelta por mí):
   frutas = ["mango", "fresa", "uva", "kiwi"]
   print(f"Lista: {frutas}")
   try:
       print(f"frutas[10] = {frutas[10]}")
   except IndexError as e:
       print(f"IndexError capturado: {e}")
       print(f"La lista solo tiene {len(frutas)} elementos (índices 0 a {len(frutas)-1})")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 12.3: Manejar ValueError y ZeroDivisionError
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo usar múltiples except en Python. El ejercicio
   divide 10 entre un número ingresado y debe manejar tanto el
   ValueError (si no es número) como ZeroDivisionError (si es 0)."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: calcular la raíz cuadrada de un número,
   manejando ValueError si no es número y ValueError si es negativo."

4. Resolución del proceso similar (resuelta por mí):
   import math
   entrada = input("Ingresa un número para sacar su raíz: ")
   try:
       numero = float(entrada)
       if numero < 0:
           raise ValueError("No se puede calcular raíz de un número negativo")
       resultado = math.sqrt(numero)
       print(f"Raíz de {numero} = {resultado}")
   except ValueError as e:
       print(f"ValueError: {e}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 13 — DECORADORES
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 13.1: Decorador que imprime "Iniciando..."
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es un decorador en Python, cómo se crea con
   una función que recibe otra función como argumento y retorna
   un wrapper. El ejercicio crea @iniciar que imprime un mensaje
   antes de ejecutar la función decorada."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un decorador @finalizar que
   imprima 'Proceso terminado.' después de ejecutar la función."

4. Resolución del proceso similar (resuelta por mí):
   def finalizar(funcion):
       def wrapper(*args, **kwargs):
           resultado = funcion(*args, **kwargs)
           print("Proceso terminado.")
           return resultado
       return wrapper

   @finalizar
   def calcular(a, b):
       print(f"Calculando {a} + {b} = {a + b}")

   calcular(5, 3)
   # Imprime: "Calculando 5 + 3 = 8" y luego "Proceso terminado."

5. ¿Necesitó repetición? Sí. Se repitió para entender el flujo:
   la función wrapper envuelve la original, ejecuta código antes
   y/o después, y retorna el resultado de la original.

──────────────────────────────────────────────────────────────
EJERCICIO 13.2: Decorador @validar_positivo
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo un decorador puede validar los argumentos
   de una función antes de ejecutarla. El ejercicio crea
   @validar_positivo que bloquea la ejecución si el número <= 0."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un decorador @validar_par que
   solo permita ejecutar la función si el número es par."

4. Resolución del proceso similar (resuelta por mí):
   def validar_par(funcion):
       def wrapper(numero):
           if numero % 2 != 0:
               print(f"Error: {numero} no es par, operación cancelada.")
               return None
           return funcion(numero)
       return wrapper

   @validar_par
   def mitad(numero):
       return numero // 2

   print(mitad(8))   # 4
   print(mitad(7))   # Error: 7 no es par

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 13.3: Decorador @log
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué imprime la función decorada con @log cuando
   se llama suma(2,3). ¿En qué orden se ejecutan el wrapper
   y la función original?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un decorador @cronometro que
   imprima 'Ejecutando...' antes y 'Listo.' después, y aplicarlo
   a una función que haga un cálculo."

4. Resolución del proceso similar (resuelta por mí):
   def cronometro(funcion):
       def wrapper(*args, **kwargs):
           print("Ejecutando...")
           resultado = funcion(*args, **kwargs)
           print("Listo.")
           return resultado
       return wrapper

   @cronometro
   def multiplicar(a, b):
       return a * b

   resultado = multiplicar(4, 5)
   print(f"Resultado: {resultado}")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 14 — UNPACKING
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 14.1: Desempaquetar tupla con *mitad
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame el unpacking extendido en Python. ¿Cómo funciona
   primera, *mitad, ultima = (10, 20, 30, 40) y qué contiene
   cada variable?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: desempaquetar una lista de 6 elementos
   tomando el primero, los cuatro del medio y el último."

4. Resolución del proceso similar (resuelta por mí):
   datos = [100, 200, 300, 400, 500, 600]
   primero, *centro, ultimo = datos

   print(f"Lista:    {datos}")
   print(f"Primero:  {primero}")
   print(f"Centro:   {centro}")
   print(f"Último:   {ultimo}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 14.2: Usar *lista para pasar argumentos
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo el operador * desempaqueta una lista para
   pasarla como argumentos individuales a una función. El ejercicio
   usa *lista en multiplicar(a, b, c)."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear una función suma_tres(a,b,c)
   y llamarla usando *lista con una lista de 3 números."

4. Resolución del proceso similar (resuelta por mí):
   def suma_tres(a, b, c):
       return a + b + c

   numeros = [10, 20, 30]
   resultado = suma_tres(*numeros)

   print(f"lista = {numeros}")
   print(f"suma_tres(*lista) = {resultado}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 14.3: Combinar diccionarios con **
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo combinar dos diccionarios en Python usando
   {**dict1, **dict2}. ¿Por qué el original no se modifica?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio parecido: combinar un diccionario de datos
   personales con uno de datos de contacto en uno solo, sin
   modificar los originales."

4. Resolución del proceso similar (resuelta por mí):
   personales = {"nombre": "Sofia", "edad": 22}
   contacto = {"email": "sofia@mail.com", "telefono": "0999"}

   perfil_completo = {**personales, **contacto}

   print(f"personales:      {personales}")
   print(f"contacto:        {contacto}")
   print(f"perfil completo: {perfil_completo}")
   # Los originales no cambian

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 15 — FUNCIONES DE ORDEN SUPERIOR
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 15.1: map() con lambda
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es map() en Python y cómo se usa con una lambda.
   El ejercicio incrementa en 1 cada elemento de una lista."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: usar map() con lambda para convertir
   una lista de temperaturas en Celsius a Fahrenheit."

4. Resolución del proceso similar (resuelta por mí):
   celsius = [0, 20, 37, 100]
   fahrenheit = list(map(lambda c: c * 9/5 + 32, celsius))

   print(f"Celsius:    {celsius}")
   print(f"Fahrenheit: {fahrenheit}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 15.2: filter() con lambda
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona filter() en Python y cuándo conviene
   usarlo sobre una list comprehension. El ejercicio filtra los
   elementos mayores a 3."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: usar filter() para obtener solo los
   nombres de una lista que tengan más de 4 letras."

4. Resolución del proceso similar (resuelta por mí):
   nombres = ["Ana", "Carlos", "Mia", "Sebastián", "Lu", "Valentina"]
   largos = list(filter(lambda n: len(n) > 4, nombres))

   print(f"Todos los nombres:  {nombres}")
   print(f"Más de 4 letras:    {largos}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 15.3: reduce() con lambda
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo funciona reduce() de functools en Python.
   ¿Cómo acumula el resultado aplicando la función de a dos
   elementos? El ejercicio multiplica todos los elementos."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: usar reduce() para encontrar el
   número mayor de una lista sin usar max()."

4. Resolución del proceso similar (resuelta por mí):
   from functools import reduce

   numeros = [3, 7, 2, 9, 1, 5]
   maximo = reduce(lambda a, b: a if a > b else b, numeros)

   print(f"Lista:   {numeros}")
   print(f"Máximo:  {maximo}")

5. ¿Necesitó repetición? Sí. Se repitió para visualizar cómo
   reduce() aplica la función acumulativamente:
   (3,7)→7, (7,2)→7, (7,9)→9, (9,1)→9, (9,5)→9


================================================================
BLOQUE 16 — ARCHIVOS Y JSON
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 16.1: Escribir y leer un archivo .txt
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo abrir, escribir y leer archivos .txt en Python
   usando with open(). ¿Cuál es la diferencia entre el modo 'w'
   y 'r'?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: pedir al usuario 3 líneas de texto,
   guardarlas en un archivo notas.txt y luego leerlo mostrando
   el contenido."

4. Resolución del proceso similar (resuelta por mí):
   lineas = []
   for i in range(1, 4):
       linea = input(f"Línea {i}: ")
       lineas.append(linea)

   with open("notas.txt", "w", encoding="utf-8") as archivo:
       for linea in lineas:
           archivo.write(linea + "\n")

   with open("notas.txt", "r", encoding="utf-8") as archivo:
       contenido = archivo.read()

   print(f"\nContenido del archivo:\n{contenido}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 16.2: Guardar y cargar JSON con json.dump / json.load
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo guardar un diccionario Python en un archivo
   JSON con json.dump() y cómo cargarlo de vuelta con json.load()."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: guardar los datos de un estudiante
   (nombre, carrera, semestre) en un archivo JSON y luego cargarlo."

4. Resolución del proceso similar (resuelta por mí):
   import json

   nombre = input("Nombre: ")
   carrera = input("Carrera: ")
   semestre = int(input("Semestre: "))

   estudiante = {"nombre": nombre, "carrera": carrera, "semestre": semestre}

   with open("estudiante.json", "w", encoding="utf-8") as f:
       json.dump(estudiante, f, indent=2, ensure_ascii=False)

   with open("estudiante.json", "r", encoding="utf-8") as f:
       cargado = json.load(f)

   print(f"\nDatos cargados: {cargado}")

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 16.3: Guardar lista de usuarios en JSON y recorrer
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo guardar una lista de diccionarios en JSON en
   Python. El ejercicio guarda 2 usuarios con nombre y edad,
   los carga y los recorre con for."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: guardar una lista de 3 productos
   (nombre, precio) en JSON, cargarlos y mostrar cuál es el
   más caro."

4. Resolución del proceso similar (resuelta por mí):
   import json

   productos = []
   for i in range(1, 4):
       print(f"\nProducto {i}:")
       nombre = input("  Nombre: ")
       precio = float(input("  Precio: "))
       productos.append({"nombre": nombre, "precio": precio})

   with open("productos.json", "w", encoding="utf-8") as f:
       json.dump(productos, f, indent=2, ensure_ascii=False)

   with open("productos.json", "r", encoding="utf-8") as f:
       datos = json.load(f)

   mas_caro = max(datos, key=lambda p: p["precio"])
   print(f"\nProducto más caro: {mas_caro['nombre']} (${mas_caro['precio']})")

5. ¿Necesitó repetición? No.


================================================================
BLOQUE 17 — MIXINS
================================================================

──────────────────────────────────────────────────────────────
EJERCICIO 17.1: PromedioMixin + Estudiante
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame qué es un Mixin en Python y cómo se usa herencia
   múltiple con él. El ejercicio tiene PromedioMixin con el método
   calcular_promedio() y la clase Estudiante lo hereda."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un MaximoMixin con un método
   calcular_maximo(valores) y una clase Grupo que lo use para
   encontrar la nota más alta."

4. Resolución del proceso similar (resuelta por mí):
   class MaximoMixin:
       def calcular_maximo(self, valores):
           return max(valores)

   class Grupo(MaximoMixin):
       def __init__(self, nombre, notas):
           self.nombre = nombre
           self.notas = notas

       def mostrar_maximo(self):
           maximo = self.calcular_maximo(self.notas)
           print(f"Nota más alta del grupo '{self.nombre}': {maximo}")

   g1 = Grupo("Matemáticas", [7, 9, 5, 10, 8])
   g1.mostrar_maximo()

5. ¿Necesitó repetición? Sí. Se repitió para entender que un
   Mixin NO es una clase base conceptual, sino un complemento
   de funcionalidad que se hereda para no repetir código.

──────────────────────────────────────────────────────────────
EJERCICIO 17.2: ValidacionMixin + Usuario
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo un Mixin puede agregar lógica de validación
   a una clase. El ejercicio usa ValidacionMixin con validar_email()
   y validar_edad() en la clase Usuario."

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un PasswordMixin con un método
   validar_password(pwd) que verifique que tenga al menos 8
   caracteres y un número."

4. Resolución del proceso similar (resuelta por mí):
   class PasswordMixin:
       def validar_password(self, pwd):
           tiene_numero = any(c.isdigit() for c in pwd)
           return len(pwd) >= 8 and tiene_numero

   class Cuenta(PasswordMixin):
       def __init__(self, usuario, password):
           self.usuario = usuario
           self.password = password

       def crear(self):
           if self.validar_password(self.password):
               print(f"[OK] Cuenta '{self.usuario}' creada exitosamente")
           else:
               print("[ERROR] Contraseña débil: mínimo 8 caracteres y un número")

   Cuenta("ana", "abc").crear()          # Error
   Cuenta("luis", "segura123").crear()   # OK

5. ¿Necesitó repetición? No.

──────────────────────────────────────────────────────────────
EJERCICIO 17.3: ExportarMixin + Reporte (JSON y CSV)
──────────────────────────────────────────────────────────────

1. IA utilizada: Claude

2. Prompt utilizado para entender y resolver el ejercicio:
   "Explícame cómo ExportarMixin agrega capacidades de exportación
   a la clase Reporte sin que Reporte tenga que implementarlas.
   ¿Cómo genera el CSV manualmente a partir de una lista de dicts?"

3. Prompt para generar un proceso similar:
   "Dame ejercicio similar: crear un ResumenMixin con un método
   que genere un resumen de texto plano de los datos, y aplicarlo
   a una clase Inventario."

4. Resolución del proceso similar (resuelta por mí):
   class ResumenMixin:
       def generar_resumen(self, datos):
           if not datos:
               return "Sin datos."
           lineas = [f"Total de registros: {len(datos)}"]
           for item in datos:
               linea = " | ".join(f"{k}: {v}" for k, v in item.items())
               lineas.append(f"  - {linea}")
           return "\n".join(lineas)

   class Inventario(ResumenMixin):
       def __init__(self, productos):
           self.productos = productos

       def mostrar(self):
           print(self.generar_resumen(self.productos))

   inv = Inventario([
       {"producto": "Silla", "cantidad": 5, "precio": 50},
       {"producto": "Mesa", "cantidad": 2, "precio": 150}
   ])
   inv.mostrar()

5. ¿Necesitó repetición? No.

```

/////////////////////////////////
/mi_menu/
from core.utilidades import gotoxy, limpiar, pausa
from core.validaciones import pedir_opcion
from menus.menus_examen import MenuExamen

COL    = 3
FILA   = 1
ANCHO  = 30
ALTO   = 8


class MiMenu:

    def _dibujar_borde(self):
        gotoxy(COL, FILA)
        print("/" * ANCHO, end="", flush=True)
        for i in range(1, ALTO - 1):
            gotoxy(COL, FILA + i)
            print("/", end="", flush=True) 
            gotoxy(COL + ANCHO - 1, FILA + i)
            print("/", end="", flush=True)
        gotoxy(COL, FILA + ALTO - 1)
        print("/" * ANCHO, end="", flush=True)

    def _dibujar_contenido(self):
        col_texto = COL + 2

        gotoxy(col_texto, FILA + 1)
        print("MENU PRINCIPAL")

        gotoxy(col_texto, FILA + 2)
        print("-" * (ANCHO - 4))

        gotoxy(col_texto, FILA + 3)
        print("1. Ejercicios")

        gotoxy(col_texto, FILA + 4)
        print("2. Salir")

    def mostrar_menu(self):
        while True:
            limpiar()
            self._dibujar_borde()
            self._dibujar_contenido()

            gotoxy(COL + 2, FILA + ALTO + 1)
            opcion = pedir_opcion("Seleccione una opcion: ", 1, 2)

            if opcion == 1:
                MenuExamen().mostrar_menu()
            elif opcion == 2:
                limpiar()
                break



/////////////
/menus_examen

from core.utilidades import gotoxy, limpiar, pausa
from core.validaciones import pedir_opcion
from bloques.examen import BloqueExamen

COL   = 3
FILA  = 1
ANCHO = 30
ALTO  = 9


class MenuExamen:

    def _dibujar_borde(self):
        gotoxy(COL, FILA)
        print("/" * ANCHO, end="", flush=True)
        for i in range(1, ALTO - 1):
            gotoxy(COL, FILA + i)
            print("/", end="", flush=True)
            gotoxy(COL + ANCHO - 1, FILA + i)
            print("/", end="", flush=True)
        gotoxy(COL, FILA + ALTO - 1)
        print("/" * ANCHO, end="", flush=True)

    def _dibujar_contenido(self, ejercicios):
        col_texto = COL + 2

        gotoxy(col_texto, FILA + 1)
        print("MENU EXAMEN")

        gotoxy(col_texto, FILA + 2)
        print("-" * (ANCHO - 4))

        for i, ejercicio in enumerate(ejercicios):
            gotoxy(col_texto, FILA + 3 + i)
            print(f"{ejercicio[0]}. {ejercicio[2]}")

        gotoxy(col_texto, FILA + 3 + len(ejercicios) + 1)
        print("0. Volver")

    def mostrar_menu(self):
        bloque = BloqueExamen()
        ejercicios = bloque.get_ejercicios()
        ultimo = ejercicios[-1][0]

        while True:
            limpiar()
            self._dibujar_borde()
            self._dibujar_contenido(ejercicios)

            gotoxy(COL + 2, FILA + ALTO + 1)
            opcion = pedir_opcion("Seleccione una opcion: ", 0, ultimo)

            if opcion == 0:
                break

            for ejercicio in ejercicios:
                if ejercicio[0] == opcion:
                    limpiar()
                    ejercicio[1]()
                    print()
                    pausa()
                    break

////////////////////
/examen/ en bloques

from core import titulo, limpiar


class BloqueExamen:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Ejercicio 1 del test'),
            (2, self.ejercicio2, 'Ejercicio 2 del test'),
            (3, self.ejercicio3, 'Ejercicio 3 del test'),
        ]

    def ejercicio1(self):
        titulo("Ejercicio 1")
        # Escribe aqui tu ejercicio 1
        print("Ejercicio 1 pendiente de completar.")

    def ejercicio2(self):
        titulo("Ejercicio 2")
        # Escribe aqui tu ejercicio 2
        print("Ejercicio 2 pendiente de completar.")

    def ejercicio3(self):
        titulo("Ejercicio 3")
        # Escribe aqui tu ejercicio 3
        print("Ejercicio 3 pendiente de completar.")


////////////////////////////
/main/

from menus.mi_menu import MiMenu

if __name__ == '__main__':
    MiMenu().mostrar_menu()