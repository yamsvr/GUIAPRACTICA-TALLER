from core import titulo, limpiar


class Bloque9Tuplas:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Crear una tupla e intentar modificarla (inmutabilidad)'),
            (2, self.ejercicio2, 'Unpacking de tupla con *resto'),
            (3, self.ejercicio3, 'Recorrer coordenadas desempaquetando x, y en el for'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 9: TUPLAS')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Crear una tupla e intentar modificarla (inmutabilidad)"""
        print('\nEjercicio 1: Crear una tupla e intentar modificarla')

        tupla = (10, 20, 30, 40)
        print(f'  Tupla: {tupla}')

        try:
            tupla[0] = 100
        except TypeError as e:
            print(f'  TypeError: {e}')
            print('  → Las tuplas son inmutables, no se pueden modificar')

    def ejercicio2(self):
        """Unpacking de tupla con *resto"""
        print('\nEjercicio 2: Usar unpacking con una tupla')

        valores = (100, 200, 300, 400)
        a, b, *resto = valores

        print(f'  tupla:  {valores}')
        print(f'  a:      {a}')
        print(f'  b:      {b}')
        print(f'  *resto: {resto}')

    def ejercicio3(self):
        """Recorrer coordenadas desempaquetando x, y en el for"""
        print('\nEjercicio 3: Recorrer una lista de coordenadas desempaquetando x, y')

        coordenadas = [(12, 34), (56, 78), (90, 12)]

        for x, y in coordenadas:
            print(f'  x={x}, y={y}')
