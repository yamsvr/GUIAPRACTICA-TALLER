from core import titulo, limpiar, pedir_texto, pedir_entero, pedir_decimal


class Bloque4EntradaSalida:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Pedir nombre y edad al usuario y mostrar un saludo'),
            (2, self.ejercicio2, 'Pedir dos números y calcular su suma y promedio'),
            (3, self.ejercicio3, "Ingresar un número como texto y concatenarlo con '5'"),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 4: ENTRADA Y SALIDA')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Pedir nombre y edad al usuario y mostrar un saludo"""
        print('\nEjercicio 1: Pedir nombre y edad al usuario y mostrar un saludo')

        nombre = pedir_texto('Ingrese su nombre: ', solo_letras=True)
        edad = pedir_entero('Ingrese su edad: ', minimo=0)

        print(f'Hola {nombre}, tienes {edad} años.')

    def ejercicio2(self):
        """Pedir dos números y calcular su suma y promedio"""
        print('\nEjercicio 2: Pedir dos números, calcular su suma y promedio')

        num1 = pedir_decimal('Ingrese el primer número: ')
        num2 = pedir_decimal('Ingrese el segundo número: ')

        suma = num1 + num2
        promedio = suma / 2

        print(f'  Suma:     {suma}')
        print(f'  Promedio: {promedio}')

    def ejercicio3(self):
        """Ingresar un número como texto y concatenarlo con '5'"""
        print('\nEjercicio 3: Ingresar un número como texto y concatenarlo con "5"')

        numero = pedir_texto('Ingrese un número: ')
        resultado = numero + '5'

        print(f'  numero + "5" = {resultado}')
        print('  → Al ser texto, Python concatena en lugar de sumar')
