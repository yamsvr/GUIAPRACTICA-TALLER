from core import titulo, limpiar, pedir_texto, pedir_entero, pedir_opcion
from pathlib import Path
import json


class PromedioMixin:
    def calcular_promedio(self, notas):
        return sum(notas) / len(notas)


class Estudiante(PromedioMixin):
    def __init__(self, nombre, notas):
        self.nombre = nombre
        self.notas = notas

    def mostrar_promedio(self):
        promedio = self.calcular_promedio(self.notas)
        print(f'Promedio de {self.nombre}: {promedio}')


class ValidacionMixin:
    def validar_email(self, correo):
        return '@' in correo and '.com' in correo

    def validar_edad(self, edad):
        return edad >= 18


class Usuario(ValidacionMixin):
    def __init__(self, nombre, correo, edad):
        self.nombre = nombre
        self.correo = correo
        self.edad = edad

    def registrar(self):
        errores = []
        if not self.validar_email(self.correo):
            errores.append('correo inválido (debe contener @ y .com)')
        if not self.validar_edad(self.edad):
            errores.append('edad inválida (debe ser >= 18)')
        if errores:
            for e in errores:
                print(f'  [ERROR] {e}')
        else:
            print(f'  [OK] Usuario "{self.nombre}" registrado correctamente')


class ExportarMixin:
    def exportar_json(self, datos):
        return json.dumps(datos, indent=2, ensure_ascii=False)

    def exportar_csv(self, datos):
        if not datos:
            return ''
        columnas = datos[0].keys()
        lineas = [','.join(columnas)]
        for fila in datos:
            lineas.append(','.join(str(fila[col]) for col in columnas))
        return '\n'.join(lineas)


class Reporte(ExportarMixin):
    def __init__(self, datos):
        self.datos = datos


class Bloque17Mixins:
    def __init__(self):
        self.carpeta = Path('datos')
        self.carpeta.mkdir(exist_ok=True)

    def _preguntar_accion(self, archivo):
        if not archivo.exists():
            return 2
        print('\n  1. Cargar datos existentes')
        print('  2. Ingresar datos nuevos')
        return pedir_opcion('Elige una opción: ', 1, 2)

    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'PromedioMixin — calcular promedio de notas de un estudiante'),
            (2, self.ejercicio2, 'ValidacionMixin — validar email y edad antes de registrar usuario'),
            (3, self.ejercicio3, 'ExportarMixin — exportar datos como JSON y como CSV'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 17: MIXINS')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """PromedioMixin — calcular promedio de notas de un estudiante"""
        print('\nEjercicio 1: PromedioMixin con calcular_promedio(notas)')
        archivo = self.carpeta / 'mixin_estudiante.json'
        accion = self._preguntar_accion(archivo)

        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                datos = json.load(f)
            estudiante = Estudiante(datos['nombre'], datos['notas'])
        else:
            nombre = pedir_texto('\nNombre del estudiante: ', solo_letras=True)
            entrada = pedir_texto('Ingresa las notas separadas por comas (ej: 8,9,10): ')
            notas = [float(x.strip()) for x in entrada.split(',')]
            datos = {'nombre': nombre, 'notas': notas}
            with open(archivo, 'w', encoding='utf-8') as f:
                json.dump(datos, f, indent=2, ensure_ascii=False)
            estudiante = Estudiante(nombre, notas)

        estudiante.mostrar_promedio()

    def ejercicio2(self):
        """ValidacionMixin — validar email y edad antes de registrar usuario"""
        print('\nEjercicio 2: ValidacionMixin con validar_email y validar_edad en Usuario')
        archivo = self.carpeta / 'mixin_usuario.json'
        accion = self._preguntar_accion(archivo)

        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                datos = json.load(f)
            usuario = Usuario(datos['nombre'], datos['correo'], datos['edad'])
        else:
            nombre = pedir_texto('\nNombre: ', solo_letras=True)
            correo = pedir_texto('Correo: ')
            edad = pedir_entero('Edad: ', minimo=0, maximo=120)
            datos = {'nombre': nombre, 'correo': correo, 'edad': edad}
            with open(archivo, 'w', encoding='utf-8') as f:
                json.dump(datos, f, indent=2, ensure_ascii=False)
            usuario = Usuario(nombre, correo, edad)

        usuario.registrar()

    def ejercicio3(self):
        """ExportarMixin — exportar datos como JSON y como CSV"""
        print('\nEjercicio 3: ExportarMixin con exportar_json y exportar_csv en Reporte')
        archivo = self.carpeta / 'mixin_reporte.json'
        accion = self._preguntar_accion(archivo)

        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                datos = json.load(f)
        else:
            print('Ingresa productos (nombre y precio). Escribe "fin" para terminar.\n')
            datos = []
            while True:
                nombre = pedir_texto('Nombre del producto (o "fin"): ')
                if nombre.lower() == 'fin':
                    break
                precio = pedir_entero('Precio: ', minimo=0)
                datos.append({'producto': nombre, 'precio': precio})
            if not datos:
                print('No ingresaste productos.')
                return
            with open(archivo, 'w', encoding='utf-8') as f:
                json.dump(datos, f, indent=2, ensure_ascii=False)

        reporte = Reporte(datos)
        print('\n--- JSON ---')
        print(reporte.exportar_json(datos))
        print('\n--- CSV ---')
        print(reporte.exportar_csv(datos))
