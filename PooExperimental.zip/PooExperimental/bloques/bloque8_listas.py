from core import titulo, limpiar, pedir_entero


class Bloque8Listas:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Crear una lista, agregar con append() y ordenar'),
            (2, self.ejercicio2, 'Calcular suma, máximo y mínimo de una lista'),
            (3, self.ejercicio3, 'Diferencia entre referencia y copia en listas'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 8: LISTAS')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Crear una lista, agregar elementos con append() y ordenar"""
        print('\nEjercicio 1: Crear una lista, agregar elementos con append() y ordenar')

        pets = []
        pets.append('Perros')
        pets.append('Gatos')
        pets.append('Loros')

        print(f'  Sin ordenar:  {pets}')
        pets.sort()
        print(f'  Ordenada:     {pets}')

    def ejercicio2(self):
        """Calcular suma, máximo y mínimo de una lista de números"""
        print('\nEjercicio 2: Calcular suma, máximo y mínimo de una lista de números')

        count = pedir_entero('¿Cuántos números desea ingresar? ', minimo=1)
        numbers = [pedir_entero(f'  Número {i + 1}: ') for i in range(count)]

        print(f'  Lista:   {numbers}')
        print(f'  Suma:    {sum(numbers)}')
        print(f'  Máximo:  {max(numbers)}')
        print(f'  Mínimo:  {min(numbers)}')

    def ejercicio3(self):
        """Diferencia entre referencia y copia en listas"""
        print('\nEjercicio 3: Diferencia entre referencia y copia en listas')

        original_list = [4, 1, 6]
        copy = original_list
        copy.append(4)

        print(f'  copy = original_list → copy.append(4)')
        print(f'  original_list: {original_list}')
        print(f'  copy:          {copy}')
        print('  → ambas cambian porque apuntan al mismo objeto')

        list2 = [4, 1, 6]
        real_copy = list2.copy()
        real_copy.append(4)

        print(f'\n  real_copy = list2.copy() → real_copy.append(4)')
        print(f'  list2:     {list2}')
        print(f'  real_copy: {real_copy}')
        print('  → list2 NO cambia con copy()')
