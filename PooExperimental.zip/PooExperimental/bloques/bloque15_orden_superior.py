from core import titulo, limpiar, pedir_texto
from functools import reduce


class Bloque15OrdenSuperior:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'map() para incrementar en 1 cada elemento de la lista'),
            (2, self.ejercicio2, 'filter() para obtener solo los elementos mayores a 3'),
            (3, self.ejercicio3, 'reduce() para multiplicar todos los elementos de la lista'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 15: FUNCIONES DE ORDEN SUPERIOR')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """map() para incrementar en 1 cada elemento de la lista"""
        print('\nEjercicio 1: Usa map() para incrementar en 1 cada elemento de tu lista')

        while True:
            entrada = pedir_texto('Ingresa números separados por comas (ej: 2,4,6): ')
            try:
                lista = [int(x.strip()) for x in entrada.split(',')]
                break
            except ValueError:
                print('  [!] Solo se permiten números enteros. Intente de nuevo.')

        resultado = list(map(lambda x: x + 1, lista))
        print(f'\n  lista original: {lista}')
        print(f'  map(+1):        {resultado}')

    def ejercicio2(self):
        """filter() para obtener solo los elementos mayores a 3"""
        print('\nEjercicio 2: Usa filter() para obtener los mayores a 3 de tu lista')

        while True:
            entrada = pedir_texto('Ingresa números separados por comas (ej: 1,2,3,4,5): ')
            try:
                lista = [int(x.strip()) for x in entrada.split(',')]
                break
            except ValueError:
                print('  [!] Solo se permiten números enteros. Intente de nuevo.')

        resultado = list(filter(lambda x: x > 3, lista))
        print(f'\n  lista original:  {lista}')
        print(f'  filter(>3):      {resultado}')

    def ejercicio3(self):
        """reduce() para multiplicar todos los elementos de la lista"""
        print('\nEjercicio 3: Usa reduce() para multiplicar todos los elementos de tu lista')

        while True:
            entrada = pedir_texto('Ingresa números separados por comas (ej: 1,2,3,4): ')
            try:
                lista = [int(x.strip()) for x in entrada.split(',')]
                break
            except ValueError:
                print('  [!] Solo se permiten números enteros. Intente de nuevo.')

        resultado = reduce(lambda x, y: x * y, lista)
        print(f'\n  lista original: {lista}')
        print(f'  reduce(*):      {resultado}')
