from core import titulo, pedir_texto, pedir_entero, pedir_opcion
import json
from pathlib import Path


class Bloque16ArchivosJson:
    def __init__(self):
        self.carpeta_datos = Path('datos')
        self.carpeta_datos.mkdir(exist_ok=True)

    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Escribir texto en un archivo .txt y leerlo'),
            (2, self.ejercicio2, 'Guardar un JSON con x e y, y volver a cargarlo'),
            (3, self.ejercicio3, 'Guardar 2 usuarios en JSON y recorrer la lista con for'),
        ]

    def ejecutar(self):
        titulo('BLOQUE 16: ARCHIVOS Y JSON')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def _preguntar_accion(self, archivo):
        if not archivo.exists():
            return 2
        print('\n  1. Cargar datos existentes')
        print('  2. Ingresar datos nuevos')
        return pedir_opcion('Elige una opción: ', 1, 2)

    def ejercicio1(self):
        """Escribir texto en un archivo .txt y leerlo"""
        print('\nejercicio 1: escribe texto en un archivo y léelo')
        archivo = self.carpeta_datos / 'archivo.txt'
        accion = self._preguntar_accion(archivo)
        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                contenido = f.read().strip()
            print(f'\nContenido guardado: {contenido}')
        else:
            texto = pedir_texto('Ingresa el texto a guardar: ')
            with open(archivo, 'w', encoding='utf-8') as f:
                f.write(texto + '\n')
            with open(archivo, 'r', encoding='utf-8') as f:
                contenido = f.read().strip()
            print(f'\nContenido leído del archivo: {contenido}')

    def ejercicio2(self):
        """Guardar un JSON con x e y, y volver a cargarlo"""
        print('\nejercicio 2: guarda un JSON con x e y, y vuelve a cargarlo')
        archivo = self.carpeta_datos / 'datos.json'
        accion = self._preguntar_accion(archivo)
        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                cargado = json.load(f)
            print(f'\nJSON cargado: {cargado}')
        else:
            x = pedir_entero('Ingresa el valor de x: ')
            y = pedir_entero('Ingresa el valor de y: ')
            datos = {'x': x, 'y': y}
            with open(archivo, 'w', encoding='utf-8') as f:
                json.dump(datos, f, indent=2, ensure_ascii=False)
            with open(archivo, 'r', encoding='utf-8') as f:
                cargado = json.load(f)
            print(f'\nJSON guardado y cargado: {cargado}')

    def ejercicio3(self):
        """Guardar 2 usuarios en JSON y recorrer la lista con for"""
        print('\nejercicio 3: guarda 2 usuarios en JSON, carga y recorre con for')
        archivo = self.carpeta_datos / 'usuarios.json'
        accion = self._preguntar_accion(archivo)
        if accion == 1:
            with open(archivo, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print('\nUsuarios cargados:')
            for u in data:
                print(f'  - {u["nombre"]}, {u["edad"]} años')
        else:
            usuarios = []
            for i in range(1, 3):
                print(f'\nUsuario {i}:')
                nombre = pedir_texto('  Nombre: ', solo_letras=True)
                edad = pedir_entero('  Edad: ', minimo=0, maximo=120)
                usuarios.append({'nombre': nombre, 'edad': edad})
            with open(archivo, 'w', encoding='utf-8') as f:
                json.dump(usuarios, f, indent=2, ensure_ascii=False)
            with open(archivo, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print('\nUsuarios guardados:')
            for u in data:
                print(f'  - {u["nombre"]}, {u["edad"]} años')
