from core import titulo, limpiar
class Bloque2TiposDatos:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Tipos de datos básicos en Python'),
            (2, self.ejercicio2, 'Indexing y slicing en listas'),
            (3, self.ejercicio3, 'Acceso a elementos de str, list y dict'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 2: VARIABLES Y TIPOS DE DATOS')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Tipos de datos básicos en Python"""
        print('\nEjercicio 1: Tipos de datos básicos en Python')

        nombre = 'Juan'
        edad = 30
        altura = 1.75
        es_estudiante = True
        lista = [1, 2, 3]
        tupla = (4, 5, 6)
        diccionario = {'clave': 'valor'}
        conjunto = {7, 8, 9}

        print(f'  nombre:        {nombre}  → {type(nombre).__name__}')
        print(f'  edad:          {edad}   → {type(edad).__name__}')
        print(f'  altura:        {altura} → {type(altura).__name__}')
        print(f'  es_estudiante: {es_estudiante} → {type(es_estudiante).__name__}')
        print(f'  lista:         {lista}  → {type(lista).__name__}')
        print(f'  tupla:         {tupla}  → {type(tupla).__name__}')
        print(f'  diccionario:   {diccionario} → {type(diccionario).__name__}')
        print(f'  conjunto:      {conjunto}  → {type(conjunto).__name__}')

    def ejercicio2(self):
        """Indexing y slicing en listas"""
        print('\nEjercicio 2: Indexing y slicing en listas')

        lista = ['mango', 'fresa', 'uva', 'sandia', 'piña']

        print(f'  lista:                  {lista}')
        print(f'  primer elemento [0]:    {lista[0]}')
        print(f'  último elemento [-1]:   {lista[-1]}')
        print(f'  slice [1:4]:            {lista[1:4]}')

    def ejercicio3(self):
        """Acceso a elementos de str, list y dict"""
        print('\nEjercicio 3: Clase con str, list y dict — acceso a sus elementos')

        texto = 'Yams'
        numeros = [2, 3]
        persona = {'nombre': 'Yams', 'edad': 20}

        print(f'  primer caracter del str:    {texto[0]}')
        print(f'  último elemento de la lista: {numeros[-1]}')
        print(f'  nombre del dict:             {persona["nombre"]}')
