from core import titulo, limpiar, pedir_texto


class Bloque12Excepciones:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Capturar ValueError al convertir texto a int'),
            (2, self.ejercicio2, 'Capturar IndexError al acceder a lista[5]'),
            (3, self.ejercicio3, 'Manejar ValueError y ZeroDivisionError en un mismo try/except'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 12: EXCEPCIONES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Capturar ValueError al convertir texto a int"""
        print('\nEjercicio 1: Captura el ValueError al convertir input del usuario a int')

        entrada = pedir_texto('Ingresa un valor: ')
        try:
            numero = int(entrada)
            print(f'Conversión exitosa: {numero}')
        except ValueError:
            print(f'ValueError: "{entrada}" no se puede convertir a int')

    def ejercicio2(self):
        """Capturar IndexError al acceder a lista[5]"""
        print('\nEjercicio 2: Captura IndexError al acceder lista[5] en una lista de 3 elementos')
        print('Ingresa los elementos separados por comas (ej: 10,20,30)')

        entrada = pedir_texto('\nElementos de la lista: ')
        lista = [x.strip() for x in entrada.split(',')]
        print(f'Lista: {lista}')
        try:
            print(f'lista[5] = {lista[5]}')
        except IndexError as e:
            print(f'IndexError capturado: {e}')

    def ejercicio3(self):
        """Manejar ValueError y ZeroDivisionError en un mismo try/except"""
        print('\nEjercicio 3: try/except que maneje ValueError y ZeroDivisionError')

        entrada = pedir_texto('Ingresa un número divisor: ')
        try:
            divisor = int(entrada)
            resultado = 10 / divisor
            print(f'10 / {divisor} = {resultado}')
        except ValueError:
            print(f'ValueError: "{entrada}" no es un número entero válido')
        except ZeroDivisionError:
            print('ZeroDivisionError: no se puede dividir entre cero')
