from .bloque0_poo import Bloque0POO
from .bloque1_constructor import Bloque1Constructor
from .bloque2_tipos_datos import Bloque2TiposDatos
from .bloque3_operadores import Bloque3Operadores
from .bloque4_entrada_salida import Bloque4EntradaSalida
from .bloque5_condicionales import Bloque5Condicionales
from .bloque6_bucles import Bloque6Bucles
from .bloque7_funciones import Bloque7Funciones
from .bloque8_listas import Bloque8Listas
from .bloque9_tuplas import Bloque9Tuplas
from .bloque10_diccionarios import Bloque10Diccionarios
from .bloque11_conjuntos import Bloque11Conjuntos
from .bloque12_excepciones import Bloque12Excepciones
from .bloque13_decoradores import Bloque13Decoradores
from .bloque14_unpacking import Bloque14Unpacking
from .bloque15_orden_superior import Bloque15OrdenSuperior
from .bloque16_archivos_json import Bloque16ArchivosJson
from .bloque17_mixins import Bloque17Mixins


BLOQUES = {
    0: ('Bloque 0 - Introducción a la POO', Bloque0POO),
    1: ('Bloque 1 - Constructor __init__', Bloque1Constructor),
    2: ('Bloque 2 - Variables y tipos de datos', Bloque2TiposDatos),
    3: ('Bloque 3 - Operadores', Bloque3Operadores),
    4: ('Bloque 4 - Entrada y salida', Bloque4EntradaSalida),
    5: ('Bloque 5 - Condicionales', Bloque5Condicionales),
    6: ('Bloque 6 - Bucles', Bloque6Bucles),
    7: ('Bloque 7 - Funciones', Bloque7Funciones),
    8: ('Bloque 8 - Listas', Bloque8Listas),
    9: ('Bloque 9 - Tuplas', Bloque9Tuplas),
    10: ('Bloque 10 - Diccionarios', Bloque10Diccionarios),
    11: ('Bloque 11 - Conjuntos', Bloque11Conjuntos),
    12: ('Bloque 12 - Excepciones', Bloque12Excepciones),
    13: ('Bloque 13 - Decoradores', Bloque13Decoradores),
    14: ('Bloque 14 - Unpacking', Bloque14Unpacking),
    15: ('Bloque 15 - Funciones de orden superior', Bloque15OrdenSuperior),
    16: ('Bloque 16 - Archivos y JSON', Bloque16ArchivosJson),
    17: ('Bloque 17 - Mixins', Bloque17Mixins),
}


__all__ = ['BLOQUES']