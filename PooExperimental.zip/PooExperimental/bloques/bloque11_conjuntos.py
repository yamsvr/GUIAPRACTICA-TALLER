from core import titulo, limpiar, pedir_texto


class Bloque11Conjuntos:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Unión, intersección y diferencia de dos conjuntos'),
            (2, self.ejercicio2, 'Eliminar duplicados de una lista usando set'),
            (3, self.ejercicio3, 'Diferencia simétrica (A|B) - (A&B)'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 11: CONJUNTOS')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Unión, intersección y diferencia de dos conjuntos"""
        print('\nEjercicio 1: Crea dos conjuntos y calcula unión, intersección y diferencia')
        print('Ingresa los elementos separados por comas (ej: 1,2,3)')

        entrada_a = pedir_texto('\nElementos del conjunto A: ')
        entrada_b = pedir_texto('Elementos del conjunto B: ')

        A = set(x.strip() for x in entrada_a.split(','))
        B = set(x.strip() for x in entrada_b.split(','))

        print(f'\n  A = {A}')
        print(f'  B = {B}')
        print(f'\n  Unión (A|B):          {A | B}')
        print(f'  Intersección (A&B):   {A & B}')
        print(f'  Diferencia (A-B):     {A - B}')

    def ejercicio2(self):
        """Eliminar duplicados de una lista usando set"""
        print('\nEjercicio 2: Elimina los duplicados de [1,2,2,3,3,3,4] usando set')

        lista = [1, 2, 2, 3, 3, 3, 4]
        sin_duplicados = list(set(lista))

        print(f'\n  Original:         {lista}')
        print(f'  Sin duplicados:   {sin_duplicados}')

    def ejercicio3(self):
        """Diferencia simétrica (A|B) - (A&B)"""
        print('\nEjercicio 3: Calcula (A|B) - (A&B) y explica el resultado')

        A = {1, 2, 3, 4}
        B = {3, 4, 5, 6}
        resultado = (A | B) - (A & B)

        print(f'\n  A = {A}')
        print(f'  B = {B}')
        print(f'\n  (A|B) - (A&B) = {resultado}')
        print('  → Es la diferencia simétrica: elementos que no se comparten entre ambos conjuntos')
