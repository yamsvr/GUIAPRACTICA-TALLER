from core import titulo, limpiar, pedir_entero


class Bloque7Funciones:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Función que calcula el doble de un número'),
            (2, self.ejercicio2, 'Función que suma varios números usando *args'),
            (3, self.ejercicio3, 'Función recursiva para calcular el factorial'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 7: FUNCIONES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Función que calcula el doble de un número"""
        print('\nEjercicio 1: Función que calcula el doble de un número')

        def calcular_doble(numero):
            return numero * 2

        numero = pedir_entero('Ingrese un número: ')
        print(f'  El doble de {numero} es {calcular_doble(numero)}')

    def ejercicio2(self):
        """Función que suma varios números usando *args"""
        print('\nEjercicio 2: Función que suma varios números usando *args')

        def suma_varios(*numeros):
            return sum(numeros)

        cantidad = pedir_entero('¿Cuántos números desea sumar? ', minimo=1)
        numeros = [pedir_entero(f'  Número {i + 1}: ') for i in range(cantidad)]
        print(f'  Suma de {numeros} = {suma_varios(*numeros)}')

    def ejercicio3(self):
        """Función recursiva para calcular el factorial"""
        print('\nEjercicio 3: Función recursiva para calcular el factorial')

        def calcular_factorial(n):
            if n == 0:
                return 1
            return n * calcular_factorial(n - 1)

        numero = pedir_entero('Ingrese un número entero positivo: ', minimo=0)
        print(f'  {numero}! = {calcular_factorial(numero)}')
