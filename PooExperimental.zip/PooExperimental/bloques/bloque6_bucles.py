from core import titulo, limpiar


class Bloque6Bucles:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Imprimir números del 1 al 10 con while'),
            (2, self.ejercicio2, 'Recorrer una lista de frutas con enumerate()'),
            (3, self.ejercicio3, 'Cuadrados de números pares del 1 al 10 con list comprehension'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 6: BUCLES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Imprimir números del 1 al 10 con while"""
        print('\nEjercicio 1: Imprimir números del 1 al 10 con while')

        contador = 1
        while contador <= 10:
            print(f'  {contador}')
            contador += 1

    def ejercicio2(self):
        """Recorrer una lista de frutas con enumerate()"""
        print('\nEjercicio 2: Recorrer una lista de frutas con enumerate()')

        frutas = ['mango', 'mandarina', 'fresa', 'kiwi']
        for indice, fruta in enumerate(frutas):
            print(f'  [{indice}] {fruta}')

    def ejercicio3(self):
        """Cuadrados de números pares del 1 al 10 con list comprehension"""
        print('\nEjercicio 3: Lista de cuadrados de números pares del 1 al 10 con list comprehension')

        cuadrados_pares = [n ** 2 for n in range(1, 11) if n % 2 == 0]
        print(f'  {cuadrados_pares}')
