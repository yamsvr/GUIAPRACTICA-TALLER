from core import titulo, limpiar, pedir_entero


def iniciar(funcion):
    def wrapper(*args, **kwargs):
        print('Iniciando...')
        return funcion(*args, **kwargs)
    return wrapper


def validar_positivo(funcion):
    def wrapper(numero):
        if numero <= 0:
            print(f'Error: {numero} no es positivo, no se calcula el cuadrado.')
            return None
        return funcion(numero)
    return wrapper


def log(funcion):
    def wrapper(*args, **kwargs):
        print('Llamando función...')
        return funcion(*args, **kwargs)
    return wrapper


class Bloque13Decoradores:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, "Decorador @iniciar que imprime 'Iniciando...' antes de la función"),
            (2, self.ejercicio2, 'Decorador @validar_positivo antes de calcular el cuadrado'),
            (3, self.ejercicio3, 'Decorador @log que registra la llamada a la función'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 13: DECORADORES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Decorador @iniciar que imprime 'Iniciando...' antes de la función"""
        print('\nEjercicio 1: decorador que imprime "Iniciando..." antes de ejecutar la función')

        @iniciar
        def saludar():
            print('Hola mundo')

        saludar()

    def ejercicio2(self):
        """Decorador @validar_positivo antes de calcular el cuadrado"""
        print('\nEjercicio 2: decorador que verifica que el argumento sea positivo antes de calcular su cuadrado')

        @validar_positivo
        def cuadrado(numero):
            return numero ** 2

        numero = pedir_entero('Ingresa un número: ')
        resultado = cuadrado(numero)
        if resultado is not None:
            print(f'Cuadrado de {numero}: {resultado}')

    def ejercicio3(self):
        """Decorador @log que registra la llamada a la función"""
        print('\nEjercicio 3: ¿Qué imprime @log def suma(a,b) al llamar suma(2,3)?')

        @log
        def suma(a, b):
            return a + b

        resultado = suma(2, 3)
        print(f'Resultado: {resultado}')
        print('→ Imprime "Llamando función..." y luego retorna 5')
