from core import limpiar, titulo

class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
        

class Bloque0POO:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Identificar 5 clases para un sistema de bibliotecas'),
            (2, self.ejercicio2, 'Crear clase Persona e instanciar 3 objetos'),
            (3, self.ejercicio3, 'Explicar la diferencia entre clase y objeto'),
        ]

    def ejecutar(self):
        limpiar()
        titulo("Bloque 0 - introducción a la POO")
        print('ejercicos para entender los conceptos básicos de la POO')
        
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()   
    
    
    
    def ejercicio1(self):
        """Identificar 5 clases para un sistema de bibliotecas"""
        print('\nejercicio 1: identificar 5 clases para un sistema de bibliotecas')
        clases_biblioteca = [
            'Libro',
            'Usuario',
            'Bibliotecario',
            'Préstamo',
            'Catálogo'
        ]
        print('\nClases identificadas para un sistema de bibliotecas:')
        for clase in clases_biblioteca:
            print(f'- {clase}')
    
    
    
    def ejercicio2(self):
        """Crear clase Persona e instanciar 3 objetos"""
        print('\nejercicio 2: crear una clase "persona" e instacia 3 objetos')
        persona1 = Persona('Juan', 30)
        persona2 = Persona('María', 25)
        persona3 = Persona('Carlos', 40)   
        print('\nObjetos creados a partir de la clase "Persona":')
        print(f'- {persona1.nombre}, tiene {persona1.edad} años')
        print(f'- {persona2.nombre}, tiene {persona2.edad} años')
        print(f'- {persona3.nombre}, tiene {persona3.edad} años')


    def ejercicio3(self):
        """Explicar la diferencia entre clase y objeto"""
        print('\nejercicio 3: Explicar la diferencia entre clase y objeto')
        print('\nUna clase es un molde o plantilla que define las características y acciones que tendrá un objeto.')
        print('Un objeto es una instancia creada a partir de una clase, con sus propios valores.')
        
        
        print('\nEjemplo:')
        print('Clase: Persona')
        print('Objeto: persona1 = Persona("Juan", 30)')

        