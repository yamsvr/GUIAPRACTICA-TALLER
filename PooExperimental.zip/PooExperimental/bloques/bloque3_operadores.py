from core import titulo, limpiar


class Bloque3Operadores:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Operadores aritméticos'),
            (2, self.ejercicio2, 'Igualdad (==) e identidad (is) entre listas'),
            (3, self.ejercicio3, 'Precedencia de operadores'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 3: OPERADORES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Operadores aritméticos"""
        print('\nEjercicio 1: Operadores aritméticos')

        a, b = 20, 4
        print(f'  {a} + {b}  = {a + b}')
        print(f'  {a} - {b}  = {a - b}')
        print(f'  {a} * {b}  = {a * b}')
        print(f'  {a} / {b}  = {a / b}')
        print(f'  {a} % {b}  = {a % b}')
        print(f'  {a} // {b} = {a // b}')
        print(f'  {a} ** {b} = {a ** b}')

    def ejercicio2(self):
        """Igualdad (==) e identidad (is) entre listas"""
        print('\nEjercicio 2: Evaluar igualdad (==) e identidad (is) entre listas')

        lista_a = [1, 2, 3]
        lista_b = [1, 2, 3]

        print(f'  lista_a = {lista_a}')
        print(f'  lista_b = {lista_b}')
        print(f'\n  lista_a == lista_b: {lista_a == lista_b}')
        print(f'  lista_a is lista_b: {lista_a is lista_b}')

    def ejercicio3(self):
        """Precedencia de operadores"""
        print('\nEjercicio 3: Precedencia de operadores — x = 2 + 1 * 2 % 2 + (2**1)//2')

        x = 2 + 1 * 2 % 2 + (2**1)//2
        print(f'\n  Resultado: {x}')
        print('  Orden: paréntesis → ** → * % // → +')
        print('  (2**1)=2 → 1*2=2 → 2%2=0 → 2//2=1 → 2+0+1=3')
