from core import titulo, limpiar, pedir_texto


def multiplicar(a, b, c):
    return a * b * c


class Bloque14Unpacking:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Desempaquetar tupla en primera, *mitad, ultima'),
            (2, self.ejercicio2, 'Pasar lista como argumentos con *lista a multiplicar(a,b,c)'),
            (3, self.ejercicio3, 'Combinar dos diccionarios con ** sin modificar los originales'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 14: UNPACKING')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Desempaquetar tupla en primera, *mitad, ultima"""
        print('\nEjercicio 1: Desempaqueta (10, 20, 30, 40) → primera, *mitad, ultima')

        primera, *mitad, ultima = (10, 20, 30, 40)

        print(f'\n  primera = {primera}')
        print(f'  mitad   = {mitad}')
        print(f'  ultima  = {ultima}')

    def ejercicio2(self):
        """Pasar lista como argumentos con *lista a multiplicar(a,b,c)"""
        print('\nEjercicio 2: Usa *lista para pasar [2,3,4] como argumentos a multiplicar(a,b,c)')
        print('Ingresa 3 números separados por comas (ej: 2,3,4)')

        while True:
            entrada = pedir_texto('\nNúmeros: ')
            try:
                lista = [int(x.strip()) for x in entrada.split(',')]
                if len(lista) != 3:
                    print('  [!] Debes ingresar exactamente 3 números.')
                    continue
                break
            except ValueError:
                print('  [!] Solo se permiten números enteros. Intente de nuevo.')

        resultado = multiplicar(*lista)
        print(f'\n  lista = {lista}')
        print(f'  multiplicar(*lista) = {resultado}')

    def ejercicio3(self):
        """Combinar dos diccionarios con ** sin modificar los originales"""
        print('\nEjercicio 3: Combina dos diccionarios usando ** sin sobrescribir el original')
        print('Formato: clave:valor separados por comas (ej: a:1,b:2)\n')

        def pedir_diccionario(etiqueta):
            while True:
                entrada = pedir_texto(f'{etiqueta}: ')
                try:
                    partes = entrada.split(',')
                    resultado = {}
                    for p in partes:
                        if ':' not in p:
                            raise ValueError
                        clave, valor = p.split(':', 1)
                        resultado[clave.strip()] = valor.strip()
                    return resultado
                except ValueError:
                    print('  [!] Formato incorrecto. Usa clave:valor separados por comas (ej: a:1,b:2).')

        dict1 = pedir_diccionario('Diccionario 1')
        dict2 = pedir_diccionario('Diccionario 2')

        combinado = {**dict1, **dict2}

        print(f'\n  dict1     = {dict1}')
        print(f'  dict2     = {dict2}')
        print(f'  combinado = {combinado}')
        print(f'\n  dict1 original sigue igual: {dict1}')
