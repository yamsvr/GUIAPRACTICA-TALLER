from core import titulo, limpiar, pedir_entero, pedir_texto, pedir_decimal, gotoxy


class Bloque5Condicionales:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Verificar si un número es par o impar'),
            (2, self.ejercicio2, 'Asignar calificación en letra según la nota (0-10)'),
            (3, self.ejercicio3, 'Sistema de login con usuario y contraseña'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 5: CONDICIONALES')
        self.ejercicio1()
        self.ejercicio2()
        self.ejercicio3()

    def ejercicio1(self):
        """Verificar si un número es par o impar"""
        gotoxy(2, 6)
        print('Ejercicio 1: Verificar si un número es par o impar')

        gotoxy(2, 7)
        numero = pedir_entero('  Ingrese un número: ')

        gotoxy(2, 8)
        if numero % 2 == 0:
            print(f'  Resultado: {numero} es par.   ')
        else:
            print(f'  Resultado: {numero} es impar. ')

    def ejercicio2(self):
        """Asignar calificación en letra según la nota (0-10)"""
        gotoxy(2, 10)
        print('Ejercicio 2: Asignar calificación en letra según la nota')

        gotoxy(2, 11)
        nota = pedir_decimal('  Ingrese una nota (0-10): ', minimo=0, maximo=10)

        if nota >= 9:
            letra = 'A'
        elif nota >= 8:
            letra = 'B'
        elif nota >= 7:
            letra = 'C'
        else:
            letra = 'D'

        gotoxy(2, 12)
        print(f'  Resultado: Nota {nota} → Calificación: {letra}')

    def ejercicio3(self):
        """Sistema de login con usuario y contraseña"""
        gotoxy(2, 14)
        print('Ejercicio 3: Sistema de login con usuario y contraseña')

        fila_error   = 15
        fila_usuario = 16
        fila_pass    = 17
        fila_ok      = 18

        while True:
            gotoxy(2, fila_usuario)
            print(' ' * 44, end='', flush=True)
            gotoxy(2, fila_pass)
            print(' ' * 44, end='', flush=True)

            gotoxy(2, fila_usuario)
            usuario = pedir_texto('  Ingrese su usuario:    ')
            gotoxy(2, fila_pass)
            contrasena = pedir_texto('  Ingrese su contraseña: ')

            if usuario == 'admin' and contrasena == '123':
                gotoxy(2, fila_error)
                print(' ' * 50, end='', flush=True)
                gotoxy(2, fila_ok)
                print('  ¡Bienvenido!                    ')
                break
            else:
                gotoxy(2, fila_error)
                print('  [!] Credenciales incorrectas. Intente de nuevo.')
