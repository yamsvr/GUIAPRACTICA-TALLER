from core import titulo, limpiar


class Bloque10Diccionarios:
    def get_ejercicios(self):
        return [
            (1, self.Ejercicio1_diccionario,          'Crear dict de persona y acceder con [] y get()'),
            (2, self.Ejercicio2_iterar_diccionario,   'Iterar sobre los items del dict con clave y valor'),
            (3, self.Ejercicio3_referencia_diccionario, 'Diferencia entre referencia y copia en diccionarios'),
        ]

    def ejecutar(self):
        limpiar()
        titulo('BLOQUE 10: DICCIONARIOS')
        self.Ejercicio1_diccionario()
        self.Ejercicio2_iterar_diccionario()
        self.Ejercicio3_referencia_diccionario()

    def Ejercicio1_diccionario(self):
        """Crear dict de persona y acceder con [] y get()"""
        print('\nEjercicio 1: Crea un dict de persona con nombre, edad y ciudad')

        persona = {
            'nombre': 'Yami',
            'edad': 20,
            'ciudad': 'Durán'
        }

        print(f'\nAcceso con []:  nombre={persona["nombre"]}, edad={persona["edad"]}, ciudad={persona["ciudad"]}')
        print(f'Acceso con get(): nombre={persona.get("nombre")}, telefono={persona.get("telefono", "No existe")}')

    def Ejercicio2_iterar_diccionario(self):
        """Iterar sobre los items del dict con clave y valor"""
        print('\nEjercicio 2: Itera sobre los items del dict e imprime cada clave y valor')

        persona = {
            'nombre': 'Yami',
            'edad': 20,
            'ciudad': 'Durán'
        }

        for clave, valor in persona.items():
            print(f'  {clave}: {valor}')

    def Ejercicio3_referencia_diccionario(self):
        """Diferencia entre referencia y copia en diccionarios"""
        print('\nEjercicio 3: ¿Qué pasa si haces copia=datos y luego copia["b"]=2?')

        datos = {'a': 1}
        copia = datos
        copia['b'] = 2

        print(f'\n  datos: {datos}')
        print(f'  copia: {copia}')
        print('  → datos también cambia porque ambas variables apuntan al mismo objeto')

        datos2 = {'a': 1}
        copia_real = datos2.copy()
        copia_real['b'] = 2

        print(f'\n  Usando copy():')
        print(f'  datos2:     {datos2}')
        print(f'  copia_real: {copia_real}')
        print('  → datos2 NO cambia')
