from core import titulo, limpiar

class Producto:
    def __init__(self, codigo, nombre, precio):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio
        if self.precio < 0:
            raise ValueError("El precio no puede ser negativo")
        
        
class Estudiante:
    def __init__(self, nombre, notas=None):
        self.nombre = nombre
        if notas is None:
            self.notas = []
        else:
            self.notas = notas
    @classmethod
    def desde_diccionario(cls, datos):
        return cls(datos['nombre'], datos.get('notas', []))
        
class Bloque1Constructor:
    def get_ejercicios(self):
        return [
            (1, self.ejercicio1, 'Crear clase Producto con constructor que valida el precio'),
            (2, self.ejercicio2, 'Estudiante con notas=None — lista vacía y classmethod'),
        ]

    def ejecutar(self):
        limpiar()
        titulo("Bloque 1 - Constructor __init__")
        print('Ejercicos para entender el constructor __init__ en Python')
        
        self.ejercicio1()
        self.ejercicio2()
    
    
    def ejercicio1(self):
        """Crear clase Producto con constructor que valida el precio"""
        print('\nEjercicio 1: crear una clase "Producto" con un constructor que reciba el nombre y precio')
        producto1 = Producto('P001', 'Laptop', 900)
        producto2 = Producto('P002', 'Mouse', 25)
        print(f'\nProducto creado: [{producto1.codigo}] {producto1.nombre}, Precio: ${producto1.precio}')
        print(f'\nProducto creado: [{producto2.codigo}] {producto2.nombre}, Precio: ${producto2.precio}')





    def ejercicio2(self):
        """Estudiante con notas=None — lista vacía y classmethod desde_diccionario"""
        print('\nCrea Estudiante con nombre y notas=None. Si no hay notas, inicia lista vacía')
       
        estudiante1 = Estudiante('Ana')
        estudiante2 = Estudiante('Carlos', [8, 9, 7])
        print(f'\nEstudiante creado: {estudiante1.nombre}, Notas: {estudiante1.notas}')
        print(f'\nEstudiante creado: {estudiante2.nombre}, Notas: {estudiante2.notas}')
        
       #estudiante desde diccionario
        datos_estudiante = {
            'nombre': 'Laura',
            'notas': [92, 88, 95]
        }
       
      
        estudiante = Estudiante.desde_diccionario(datos_estudiante)
        print(f'\nEstudiante creado: {estudiante.nombre}, Notas: {estudiante.notas}')