from core import limpiar, aviso, pausa, pedir_opcion, gotoxy
from bloques import BLOQUES

# Posiciones fijas en la pantalla
COL_IZQUIERDA  = 3   # columna del texto en el panel izquierdo
COL_CENTRO     = 47  # columna del texto en el panel derecho
FILA_TITULO    = 2   # fila del título
FILA_SEP       = 3   # fila del separador
FILA_LABEL     = 4   # fila de la etiqueta "Ejercicios:"
FILA_ITEMS     = 5   # fila donde empiezan los ítems
ALTO_PANEL     = 26  # altura del panel izquierdo
ANCHO_PANEL    = 42  # ancho del panel izquierdo
ANCHO_PANTALLA = 80  # ancho de la pantalla


class MenuBloques:
    def __init__(self):
        self.bloques = BLOQUES

    def _dibujar_borde(self, col, fila, ancho, alto):
        gotoxy(col, fila)
        print("/" * ancho, end="", flush=True)
        for i in range(1, alto - 1):
            gotoxy(col, fila + i)
            print("/", end="", flush=True)
            gotoxy(col + ancho - 1, fila + i)
            print("/", end="", flush=True)
        gotoxy(col, fila + alto - 1)
        print("/" * ancho, end="", flush=True)

    def _cabecera_ejercicio(self, nombre_bloque, num_ejercicio):
        texto = "  " + nombre_bloque + "  -  Ejercicio " + str(num_ejercicio) + "  "
        if len(texto) > ANCHO_PANTALLA - 2:
            texto = texto[:ANCHO_PANTALLA - 5] + "...  "
        espacios = ANCHO_PANTALLA - 2 - len(texto)
        gotoxy(1, 1)
        print("/" * ANCHO_PANTALLA)
        gotoxy(1, 2)
        print("/" + texto + " " * espacios + "/")
        gotoxy(1, 3)
        print("/" * ANCHO_PANTALLA)
        gotoxy(1, 5)

    def _panel_izquierdo(self, seleccionado=None):
        self._dibujar_borde(1, 1, ANCHO_PANEL, ALTO_PANEL)

        ancho_nombre = ANCHO_PANEL - 11

        gotoxy(COL_IZQUIERDA, FILA_TITULO)
        print("Menu de Bloques")

        gotoxy(COL_IZQUIERDA, FILA_SEP)
        print("-" * (ANCHO_PANEL - 4))

        i = 0
        for numero in self.bloques:
            nombre = self.bloques[numero][0]
            gotoxy(COL_IZQUIERDA, FILA_ITEMS + i)
            if numero == seleccionado:
                marca = ">"
            else:
                marca = " "
            if len(nombre) > ancho_nombre:
                nombre_str = nombre[:ancho_nombre]
            else:
                nombre_str = nombre
            print(" " + marca + " " + str(numero).rjust(2) + ". " + nombre_str)
            i += 1

        gotoxy(COL_IZQUIERDA, FILA_ITEMS + len(self.bloques) + 1)
        print("    18. Salir")

    def mostrar_menu(self):
        while True:
            limpiar()
            self._panel_izquierdo()
            fila_input = ALTO_PANEL + 2
            gotoxy(COL_IZQUIERDA, fila_input)
            opcion = pedir_opcion("Seleccione un bloque: ", 0, 18)
            if opcion == 18:
                break
            elif opcion in self.bloques:
                self.mostrar_ejercicios(opcion)
            else:
                gotoxy(COL_IZQUIERDA, fila_input + 1)
                aviso("Opcion no valida.")
                pausa()

    def mostrar_ejercicios(self, numero_bloque):
        nombre_bloque = self.bloques[numero_bloque][0]
        ClaseBloque = self.bloques[numero_bloque][1]
        instancia = ClaseBloque()
        ejercicios = instancia.get_ejercicios()

        while True:
            limpiar()
            self._panel_izquierdo(seleccionado=numero_bloque)

            gotoxy(COL_CENTRO, FILA_TITULO)
            print(nombre_bloque)

            gotoxy(COL_CENTRO, FILA_SEP)
            print("-" * 36)

            gotoxy(COL_CENTRO, FILA_LABEL)
            print("Ejercicios:")

            i = 0
            for ejercicio in ejercicios:
                num         = ejercicio[0]
                descripcion = ejercicio[2]
                gotoxy(COL_CENTRO, FILA_ITEMS + i)
                print("  " + str(num) + ". " + descripcion)
                i += 1

            fila_volver = FILA_ITEMS + len(ejercicios) + 1
            gotoxy(COL_CENTRO, fila_volver)
            print("   0. Volver")

            fila_input = fila_volver + 2
            fila_error = fila_input + 1
            ultimo_num = ejercicios[len(ejercicios) - 1][0]
            opcion = None
            while opcion is None:
                gotoxy(COL_CENTRO, fila_input)
                print(" " * 44, end="", flush=True)
                gotoxy(COL_CENTRO, fila_input)
                try:
                    val = int(input("Seleccione un ejercicio: "))
                    if 0 <= val <= ultimo_num:
                        opcion = val
                    elif val > ultimo_num:
                        gotoxy(COL_CENTRO, fila_error)
                        print(f"[!] Solo hay {ultimo_num} ejercicios disponibles.", end="", flush=True)
                    else:
                        gotoxy(COL_CENTRO, fila_error)
                        print(f"[!] Ingrese entre 0 y {ultimo_num}.", end="", flush=True)
                except ValueError:
                    gotoxy(COL_CENTRO, fila_error)
                    print("[!] Entrada invalida. Intente otra vez.", end="", flush=True)

            if opcion == 0:
                break

            # Buscar y ejecutar el ejercicio seleccionado
            encontrado = False
            for ejercicio in ejercicios:
                if ejercicio[0] == opcion:
                    limpiar()
                    self._cabecera_ejercicio(nombre_bloque, opcion)
                    ejercicio[1]()
                    print()
                    print("*" * ANCHO_PANTALLA)
                    pausa()
                    encontrado = True
                    break

            if not encontrado:
                gotoxy(COL_CENTRO, fila_input + 1)
                aviso("Opcion no valida.")
                pausa()
