from .utilidades import gotoxy
from .marcos import Marcos


class Menu:
    def __init__(self, titulo, opciones, col=1, fila=1, caracter='*'):
        self.titulo = titulo
        # opciones: lista de str o lista de (clave, etiqueta)
        self.opciones = opciones
        self.col = col
        self.fila = fila
        self._marcos = Marcos(caracter)

    def dibujar(self):
        etiquetas = [
            f'{op[0]}. {op[1]}' if isinstance(op, tuple) else f'{i + 1}. {op}'
            for i, op in enumerate(self.opciones)
        ]
        ancho = max(len(self.titulo), max(len(e) for e in etiquetas)) + 6
        alto = len(etiquetas) + 5  # borde + título + separador + items + borde

        self._marcos.dibujar(self.col, self.fila, ancho, alto)

        col_cont = self.col + 2

        gotoxy(col_cont, self.fila + 1)
        print(self.titulo, end='', flush=True)

        gotoxy(col_cont, self.fila + 2)
        print('-' * (ancho - 4), end='', flush=True)

        for i, etiqueta in enumerate(etiquetas):
            gotoxy(col_cont, self.fila + 3 + i)
            print(etiqueta, end='', flush=True)

        gotoxy(col_cont, self.fila + alto + 1)
