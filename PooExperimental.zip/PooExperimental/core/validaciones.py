
def pedir_texto(mensaje, solo_letras=False, obligatorio=True):
    while True:
        valor = input(mensaje).strip()
        if obligatorio and not valor:
            print('[ERROR] El campo no puede estar vacío.')
            continue
        if solo_letras and valor and not valor.replace(' ', '').isalpha():
            print('[ERROR] Solo se permiten letras y espacios.')
            continue
        return valor


def pedir_entero(mensaje, minimo=None, maximo=None):
    while True:
        try:
            valor = int(input(mensaje))
            if minimo is not None and valor < minimo:
                print(f'[ERROR] El valor mínimo permitido es {minimo}.')
                continue
            if maximo is not None and valor > maximo:
                print(f'[ERROR] El valor máximo permitido es {maximo}.')
                continue
            return valor
        except ValueError:
            print('[ERROR] Debe ingresar un número entero válido.')


def pedir_decimal(mensaje, minimo=None, maximo=None):
    while True:
        try:
            valor = float(input(mensaje))
            if minimo is not None and valor < minimo:
                print(f'[ERROR] El valor mínimo permitido es {minimo}.')
                continue
            if maximo is not None and valor > maximo:
                print(f'[ERROR] El valor máximo permitido es {maximo}.')
                continue
            return valor
        except ValueError:
            print('[ERROR] Debe ingresar un número decimal válido.')


def pedir_opcion(mensaje, minimo, maximo):
    return pedir_entero(mensaje, minimo=minimo, maximo=maximo)
