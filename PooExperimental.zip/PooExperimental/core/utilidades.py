import os

ansi_activado = False


def activar_ansi():
    global ansi_activado
    if not ansi_activado:
        if os.name == 'nt':
            os.system('')
        ansi_activado = True


def gotoxy(x, y):
    activar_ansi()
    print('\033[' + str(y) + ';' + str(x) + 'H', end='', flush=True)


def limpiar():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')


def pausa(mensaje='tecla ENTER para continuar al menú...'):
    input('\n' + mensaje)


def titulo(texto):
    print('\n' + '=' * 70)
    print(texto.center(70))
    print('=' * 70)


def aviso(mensaje):
    print('[AVISO] ' + mensaje)
