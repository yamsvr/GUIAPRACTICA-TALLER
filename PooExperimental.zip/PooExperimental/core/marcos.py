import shutil
from .utilidades import gotoxy


class Marcos:
    def __init__(self, caracter='*'):
        self.caracter = caracter

    def dibujar(self, col, fila, ancho, alto):
        c = self.caracter
        gotoxy(col, fila)
        print(c * ancho, end='', flush=True)
        for i in range(1, alto - 1):
            gotoxy(col, fila + i)
            print(c, end='', flush=True)
            gotoxy(col + ancho - 1, fila + i)
            print(c, end='', flush=True)
        gotoxy(col, fila + alto - 1)
        print(c * ancho, end='', flush=True)

    def dibujar_cabecera(self, texto, ancho=None):
        c = self.caracter
        if ancho is None:
            ancho = min(shutil.get_terminal_size((80, 24)).columns - 1, 118)
        if len(texto) > ancho - 2:
            texto = texto[:ancho - 5] + '...'
        espacios = ancho - 2 - len(texto)
        gotoxy(1, 1)
        print(c * ancho)
        gotoxy(1, 2)
        print(f'{c}{texto}{" " * espacios}{c}')
        gotoxy(1, 3)
        print(c * ancho)
        gotoxy(1, 5)
        return ancho
