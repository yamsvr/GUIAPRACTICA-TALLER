from menus import MenuBloques

if __name__ == '__main__':
    MenuBloques().mostrar_menu() 
